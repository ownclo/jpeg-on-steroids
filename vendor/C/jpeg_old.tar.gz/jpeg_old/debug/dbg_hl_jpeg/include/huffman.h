/*
	This is a header file. All functions are described and commented here. 
	Please don't try to find some reasonable documentation somewhere else. 
	README file contains little instructions about usage of the whole project. Good day!
*/

#include <stdio.h>
#include <ctype.h>

/*----------------------------------------------------------*/
/*					Structures								*/

struct node													// Element of Huffman tree.
{
	struct node* rightchild;
	struct node* leftchild;
	struct node* parent;
	unsigned char letter;									// (means if the element is a leaf) Symbol
	int weight;												// Weight of a subtree or counts of symbol frequencies.
};
struct rez 													// Representation of an element of a Huffman tree
{
	unsigned int path;										// Absolute path to that element
	unsigned int depth;										// Depth of an element in the tree. Actually, length of path
	unsigned int weight;									// Same as in node 
};

struct deco													// Analog of rez, used in decoder.
{
	char letter;
	int length;												// <=> depth. I like 'depth', actually.
};
/*----------------------------------------------------------*/

typedef struct node NODE;
typedef NODE* NODEP;
typedef struct rez REZ;
typedef REZ* REZP;
typedef struct deco DECO;
typedef DECO* DECOP;


/*----------------------------------------------------------*/
/*					High-level functions					*/

int encode (FILE* inp, REZP cd, FILE* outp);				// Encode an inp file using a codebook cd into outp

/*----------------------------------------------------------*/


/*----------------------------------------------------------*/
/*					Middle-level functions					*/

int form_tree (FILE* stream, 
				int* counts, int num_of_elms, REZP cd);		// Universal function: form a tree by the array of counters.

/*		deep-first-search related functions					*/
int dfs(NODEP root,											// In encoding: core-function (sic!).
		int num,											// Transforms recursive node* structure into
		int dep,											// rez* table by deep-first search.
		REZP cd,											// The function accumulates num (path) and
		int* nimno,											// depth (length) while plunging into the tree.
		unsigned char* alph,								// Alph is used alphabed, stored independently.
		unsigned int* treecode,								// We actually write the code of tree, tooks 1 bit 
		int* freeplace,										// per node. (sic!)
		int* cur);

NODEP dfr  (char* string,									// In decoding: function that restores a node
			int* cur,										// structure from an encoded tree in header.
			unsigned char* alphabet,
			int* curalphabet,
			NODEP parent);

int dfs_final  (NODEP root,									// Build a rez* table from node structure.
				int num,									// Both dfr and dfs_final are steps to restore
				int dep,									// the codebook from the dfs' output.
				REZP cd);

/*		afterwards conversion								*/
int refill (char wd,										// Used in decoding: from rez* to cd*
			unsigned int path,
			unsigned int depth,
			DECOP recd );
/*----------------------------------------------------------*/
int free_tree (NODE* treeptr);

/*----------------------------------------------------------*/
/*					Low-level functions						*/

int twomins (int* first, int* second, NODEP nodes, int len);	// Find two leafs with minimum weights.
int uiui   (int firstmin, int secondmin,					// Unite them and modify weights.
			int cow, NODEP nodes);

int incri (int* i, NODEP nodes, int len);					// Skip nodes. used by twomins. local service.
/*----------------------------------------------------------*/
unsigned char decosymbol (DECOP table, unsigned int* code, unsigned int* buffer, DECOP cur,
				int* current, int* s);
int add (int* freeplace, unsigned int depth, unsigned int path, unsigned int* lol, int* cur); // bit outp
unsigned int getbitstream (unsigned int* stream, int* cellnum, int* bitnum, int length);
