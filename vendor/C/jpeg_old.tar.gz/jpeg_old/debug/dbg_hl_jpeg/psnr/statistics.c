#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "../../dbg_hl_jpeg/include/low_lvl_jpeg.h"

long double psnr (short* s1, short* s2, int w, int h)
{
    int i, j;
    unsigned long long kn;
    long double k;
    long int sum = 0;
    long int tmpsq;

    kn = (unsigned long long) w * h * 255 * 255;
    for (i = 0; i < h; i++){
	for (j = 0; j < w; j++){
	    tmpsq = (long int) (s1[i*w+j] - s2[i*w+j]);
	    if (tmpsq < 2) sum = sum + tmpsq*tmpsq;   
	}
    }
    printf("sum = %ld\n", sum);
    
    k = ((double) kn) / ((double) sum);
    k = log10(k);
    return 10.*k;
}

int main (void)
{
	long double psn;
	
	PDRGB *rgbed = NULL;
	PDCBCR *cbcred = NULL;
	DCTDATA *dcted = NULL;
	PDCBCR  *cbcr_from_dct  = NULL;

	rgbed = getRGBFromFile("Ilena");
	cbcred = RGBtoCBCR(rgbed);
	dcted = vomit(cbcred, 0);
	cbcr_from_dct = returnFromDCT (dcted, 0);
			
	psn = psnr (cbcred->Ydata, cbcr_from_dct->Ydata, cbcred->w, cbcr_from_dct->h);
	printf ("psnr = %lf\n", (double) psn);
	
	freeDCT(dcted);
	freeCBCR(cbcred);
	freeCBCR(cbcr_from_dct);
	freeRGB(rgbed);
    return EXIT_SUCCESS;
}

