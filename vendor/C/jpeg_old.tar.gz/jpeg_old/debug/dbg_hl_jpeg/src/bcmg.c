#include <stdio.h>
#include <stdlib.h>
#include "./hljpeg.h"

char bc (short num)
{
	char i = 0;
	if (num == 0) return 0;	
	for (; num != 0; i++)
		num = num >> 1;
	return i;
}

int bcmg (short number, char* bcn, short* mg)
{
	if (number >= 0) 
	{
		*bcn = bc (number);
		*mg = number;
	}
	else 
	{
		*bcn = bc (-1*number);
		*mg = (~(-1*number)) & ((1 << *bcn) - 1);
	}
	return 1;
}

int bcmg_test (void)
{
	FILE* lol = fopen ("test_bcmg", "wt+");
	printf("-----------------------------------\nSTARTING TESTs OF THE BCMG MODULE\n");
	short* A;
	int i;
	char bcn = 0;
	short mg = 0;
	int k;
	A = (short*) calloc (4096, sizeof(short));
	for (i = 0; i < 4096; i++)
	{
		k = i - 2048;
		A[i] = k;
		bcmg (A[i], &bcn, &mg);
		fprintf(lol, "%d\t%d\t%d\n", k, bcn, mg);
	}
	free (A);
	fclose (lol);
	return 1;
}






