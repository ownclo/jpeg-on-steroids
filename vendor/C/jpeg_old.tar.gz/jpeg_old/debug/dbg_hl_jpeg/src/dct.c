#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "./hljpeg.h"

/* FUNCTION THAT CALCULATES ONE ELEMENT OF THE MATRICES MULTIPLICATION */
double calcelm (double x[SIZE], double T[SIZE][SIZE], int i)
{
	double rez = 0;
	int j;
	for (j = 0; j < SIZE; j++)
		rez += x[j]*T[j][i];
	return rez;
}

/* FUNCTION OF COMPUTING THE DCT of a vector X on a basis T*/
int dct_vec(double x[SIZE], double T[SIZE][SIZE], double y[SIZE])
{
	int i;
	for (i = 0; i < SIZE; i++)
		{ y[i] = calcelm(x, T, i);}
	return 1;
}

int dct_mat (double A[SIZE][SIZE], double B[SIZE][SIZE], double R[SIZE][SIZE])
{
	int i;
	for (i = 0; i < SIZE; i++)
	{
		dct_vec(A[i], B, R[i]);
	}
	return 1;
}

/* GENERATING A DCT BASIS T and it's transposed form Tt */
int genbasis (double T[SIZE][SIZE], double Tt[SIZE][SIZE])
{
	int i = 0; int j = 0;					/* Counters	*/
			
	// will generate T, then Tt, then normalize T, then Tt;
	
	for (i = 0; i < SIZE; i++) {
		for (j = 0; j < SIZE; j++) {
			T[i][j] = cos((2*j + 1)*M_PI*i/(2*SIZE));
			Tt[j][i] = T[i][j]; }}
		
	for (i = 0; i < SIZE; i++) {
		T[i][0] = T[i][0] /sqrt(SIZE); 
		Tt[i][0] = Tt[i][0] / sqrt(SIZE);
	}		 
	for (i = 0; i < SIZE; i++) {
		for (j = 1; j < SIZE; j++) { 
			T[i][j] = T[i][j] /sqrt(SIZE); 
			Tt[i][j] = Tt[i][j] / sqrt(SIZE); 
	}}

	return 1;
}

int printmat (double mat[SIZE][SIZE])
{
	int i, j;
	for (i = 0; i < SIZE; i++) {
	for (j = 0; j < SIZE; j++) {
		printf("%f\t", mat[i][j]); }
		printf("\n");}
	printf("\n");
	
	return 1;
}
int printvec (double vec[SIZE])
{
	int i;
	for (i = 0; i < SIZE; i++) {
		printf("%f\t", vec[i]);}
	printf("\n");
	return 1;
}
		
	
int main (void)
{
	printf("-----------------------------------\nSTARTING TESTs OF THE DCT MODULE\n");
	double T[SIZE][SIZE];								/* Cosine Basis */
	double R[SIZE][SIZE];
	double B[SIZE][SIZE];
	double Tt[SIZE][SIZE];								/* Transponed T */
	double x[SIZE] = {34, 33, 35, 33, 32, 33, 34, 35};	/* Exemple of X */
	double y[SIZE];
	double Rr[SIZE][SIZE]; 
	double Ex[SIZE][SIZE] = {{34, 33, 35, 33, 32, 33, 34, 35}, {34, 33, 35, 33, 32, 33, 34, 35},{34, 33, 35, 33, 32, 33, 34, 35},{34, 33, 35, 33, 32, 33, 34, 35},{34, 33, 35, 33, 32, 33, 34, 35},{34, 33, 35, 33, 32, 33, 34, 35},{34, 33, 35, 340, 32, 33, 34, 35},{34, 33, 35, 33, 32, 33, 34, 350} };	
	genbasis (T, Tt);
//	printmat(T);
//	printmat(Tt);
	printmat(Ex);	
//	dct_vec(x, Tt, y);
//	dct_vec(y, T, x);
//	dct_mat(T, Tt, R);
	dct_mat(T, Ex, R);
	dct_mat(R, Tt, Rr);
	printmat(Rr);
	dct_mat(Tt, Rr, R);
	dct_mat(R, T, B);
	printmat(B);

	return 1;
}
