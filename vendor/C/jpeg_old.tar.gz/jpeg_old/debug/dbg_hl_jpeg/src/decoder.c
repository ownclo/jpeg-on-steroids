#include <stdio.h>
#include <stdlib.h>
#include "hljpeg.h"

//int main_decode (FILE* stream, DCTDATA* result)
int main_decoder (void)
{
	FILE* stream = fopen ("O", "rb");
	rewind(stream);
	DCTDATA *result;
	result = (DCTDATA*) malloc (sizeof(DCTDATA));
	unsigned int yBlks, cBlks;
	
	fread (&result->w, sizeof (unsigned int), 1, stream);
	fread (&result->h, sizeof (unsigned int), 1, stream);	
	fread (&yBlks, sizeof (unsigned int), 1, stream);
	fread (&cBlks, sizeof (unsigned int), 1, stream);
	
	result->YBlks = yBlks;
	result->CBlks = cBlks;
	result->YdataDCT  = (short*) calloc (yBlks<<6, sizeof(short int));
	result->CbDataDCT = (short*) calloc (cBlks<<6, sizeof(short int));
	result->CrDataDCT = (short*) calloc (cBlks<<6, sizeof(short int));

	decode_component (stream, result->YdataDCT,  (int) yBlks);
	decode_component (stream, result->CbDataDCT, (int) cBlks);
	decode_component (stream, result->CrDataDCT, (int) cBlks);

/*  Debugger's version here */
	FILE* outY = fopen("Outdct_Y.data", "w");
	FILE* outCb = fopen("Outdct_Cb.data", "w");
	FILE* outCr = fopen("Outdct_Cr.data", "w");	
	fwrite(result->YdataDCT,  sizeof(short), 64*result->YBlks, outY);
	fwrite(result->CbDataDCT, sizeof(short), 64*result->CBlks, outCb);
	fwrite(result->CrDataDCT, sizeof(short), 64*result->CBlks, outCr);
	fclose(outY);
	fclose(outCb);
	fclose(outCr);
/* Do something with DCTDATA* result here */
	PDCBCR  *cbcr_from_dct  = NULL;
	PDRGB   *rgb_from_cbcr = NULL;
	cbcr_from_dct = returnFromDCT(result, 0);
	rgb_from_cbcr = CBCRtoRGB (cbcr_from_dct);
	writeToBMP ("I.deco", rgb_from_cbcr);
	

	freeCBCR(cbcr_from_dct);
	freeRGB(rgb_from_cbcr);
	freeDCT(result);
	fclose(stream);
	return EXIT_SUCCESS;
}

int decode_component (FILE* stream, short* dataDCT, int Blks)
{
	int powerofalph_dc = 0;
	int powerofalph_ac = 0;
	unsigned char *alph_ac = NULL;
	unsigned char *alph_dc = NULL;
	unsigned int *treecode_dc = NULL;
	unsigned int *treecode_ac = NULL;
	int sizeoftree_dc = 0;
	int sizeoftree_ac = 0;
	char *treecd_dc = NULL;
	char *treecd_ac = NULL;
	int sizeofcode = 0;
	unsigned int* code = NULL;
	
	
 /* HEADER PARSING, FASTEN SEAT BELTS */	

	fread (&powerofalph_dc, sizeof (int), 1, stream);
	alph_dc = (unsigned char*) malloc (powerofalph_dc * sizeof (char));
	fread (alph_dc, sizeof (char), powerofalph_dc, stream);
	sizeoftree_dc = (2*powerofalph_dc - 1)/32  + 1;
	treecode_dc = (unsigned int*) malloc (sizeof (unsigned int) * sizeoftree_dc);
	fread (treecode_dc, sizeof (int), sizeoftree_dc, stream);
				
	fread (&powerofalph_ac, sizeof (int), 1, stream);
	alph_ac = (unsigned char*) malloc ( sizeof (char) * powerofalph_ac );
	fread (alph_ac, sizeof (char), powerofalph_ac, stream);
	sizeoftree_ac = (2*powerofalph_ac - 1)/32  + 1;
	treecode_ac = (unsigned int*) malloc (sizeof (unsigned int) * sizeoftree_ac);
	fread (treecode_ac, sizeof (int), sizeoftree_ac, stream);

	fread (&sizeofcode, sizeof (int), 1, stream);
	code = (unsigned int*) malloc (sizeof (unsigned int) * sizeofcode);
	fread (code, sizeof (unsigned int), sizeofcode,  stream);
	
 /* END OF THE HEADER PARSING */	


	int i = 0;
	int celn = 0;
	int bitn = 32;
	treecd_dc = (char*) malloc (sizeof (char) * 2 * powerofalph_dc);
	treecd_ac = (char*) malloc (sizeof (char) * 2 * powerofalph_ac);
	for ( i = 0; i < (2*powerofalph_dc - 1); i++)
		treecd_dc[i] = '0' + getbits ( treecode_dc, &celn, &bitn, 1 );
	treecd_dc [i] = '\0';
	celn = 0; bitn = 32;
	for ( i = 0; i < (2*powerofalph_ac - 1); i++)
		treecd_ac[i] = '0' + getbits ( treecode_ac, &celn, &bitn, 1 );	
		
	NODEP tree_dc, tree_ac; 
	int current_bit_in_a_tree = 0; 
	int cura = 0;
	tree_dc = dfr ( treecd_dc,  &current_bit_in_a_tree,  alph_dc, &cura, NULL);
	current_bit_in_a_tree = 0; cura = 0;
	tree_ac = dfr ( treecd_ac, &current_bit_in_a_tree, alph_ac, &cura, NULL);
	
	REZ* cd_dc = calloc (16,  sizeof(REZ));
	REZ* cd_ac = calloc (256, sizeof(REZ));

	dfs_final (tree_dc, 0, 0, cd_dc);
	dfs_final (tree_ac, 0, 0, cd_ac);
	
	DECO* table_dc;
	DECO* table_ac;
	table_dc = (DECO*) calloc ((1 << 22), sizeof(DECO));
	table_ac = (DECO*) calloc ((1 << 22), sizeof(DECO));

	for (i = 0; i < 16;  i++)
	{
		if (cd_dc[i].depth != 0)
		refill ((char) i, cd_dc[i].path, cd_dc[i].depth, table_dc);
	}
	for (i = 0; i < 256; i++)
	{
		if (cd_ac[i].depth != 0)
		refill ((char) i, cd_ac[i].path, cd_ac[i].depth, table_ac);
	}

	unsigned int buffer = code[0];
	int current = 1;
	int s = 32;
	DECO cur_deco;
	unsigned char symb;
/* END OF THE PRECONFIGURATION PART */

/* Start of the block decoding's model */
	int j;
	char bcdc, bclvl;
	short mgdc, mglvl;
	unsigned char bcrle;
	unsigned char run = 200;
	short lvl = 1;
	short dc;
	short dcprev = 0;
	int cur = 0;

	for (i = 0; i < Blks; i++)
	{
		bcdc = (char) decosymbol (table_dc, code, &buffer, &cur_deco, &current, &s);
		if (bcdc != 0)
		{
			mgdc = (short) (buffer >> (32 - bcdc));
			buffer = (buffer << bcdc) | getbits (code, &current, &s, bcdc);
			dc = ((((mgdc >> (bcdc - 1))&1) == 1) ? mgdc : (-1 * ((~mgdc)&((1 << bcdc) - 1))));
			dc += dcprev;
			dcprev = dc;
		}
		else dc = dcprev;
		dataDCT[i*64 + cur] = dc;
		while (((run!=0)||(lvl!=0))&&(cur<63))
		{
			bcrle = decosymbol (table_ac, code, &buffer, &cur_deco, &current, &s);
			bclvl = bcrle >> 4;
			run   = bcrle & 15;
			mglvl = 0;
			if (bclvl != 0)
			{
				mglvl = (short) (buffer >> (32 - bclvl));
				buffer = (buffer << bclvl) | getbits (code, &current, &s, bclvl);
				lvl = ((((mglvl >> (bclvl - 1))&1) == 1) ? mglvl : (-1 * ((~mglvl)&((1 << bclvl) - 1))));
				cur += run + 1;
				dataDCT[i*64 + cur] = lvl; 
			}
			else
			{
				lvl = 0;
				cur += run + 1;				
			}
		}
		cur = 0; run = 200; lvl = 1;
	}
	
	free_tree (tree_ac);
	free_tree (tree_dc);
	free (cd_dc);
	free (cd_ac);
	free (code);
	free (treecode_ac); 
	free (treecode_dc);
	free (alph_ac); 
	free (alph_dc);
	free (treecd_ac);
	free (treecd_dc);
	free (table_dc);
	free (table_ac);
	return EXIT_SUCCESS;
}

