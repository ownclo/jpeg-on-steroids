/* THAT PART OF THE PROJECT PROVIDES THE CONNECTION BETWEEN ENTROPY CODING AND JPEG ALGORYTHM */

#include <stdio.h>
#include <stdlib.h>
#include "hljpeg.h"



int entrophy (short* zigzagged, short* dcprev, REZP cd_dc, REZP cd_ac, unsigned int* output, int* current_cell, int* freeplace)
{
	short delta = zigzagged[0]-*dcprev;
	char bcdc;
	short mgdc;

	bcmg(delta, &bcdc, &mgdc);
	putbits (cd_dc[bcdc].path, cd_dc[bcdc].depth, output, current_cell, freeplace);
	if (bcdc != 0)
	{
		*dcprev = zigzagged[0];
		putbits ((unsigned int) mgdc, (unsigned int) bcdc, output, current_cell, freeplace);
	}
	rle (zigzagged, cd_ac, output, current_cell, freeplace);
	return EXIT_SUCCESS;
}


int counters_dc (short* data, int* dc_counts, int n)
{
    int i;
    char bcdc;
    short mgdc;
    short dcprev;
    short delta_dc;
    short cur_dc;

    dcprev = data[0];
    delta_dc = dcprev;
    bcmg (delta_dc, &bcdc, &mgdc);
    dc_counts[bcdc]++;

    for (i = 1; i < n; i++)
    {
	  cur_dc = data[64*i];
	  delta_dc = cur_dc - dcprev;
	  bcmg (delta_dc, &bcdc, &mgdc);
	  dc_counts[bcdc]++;
	  dcprev = cur_dc;
    }

    return EXIT_SUCCESS;
}

int counters_ac (short* data, int* ac_counts, int n)
{
    int i;
    
    for (i = 0; i < n; i++)
    	rle_counters(&data[64*i], ac_counts);
	
	return EXIT_SUCCESS;    	
}

int rle_counters (short* block, int* ac_counts)
{
	unsigned char run = 0;
	int cur;
	int i;
	int no_zeros = 0;
	for (i = 1; i < 64; i++)
	{
		if (block[i] != 0) no_zeros++;
	}
	i = 0;
	for (cur = 1; i < no_zeros; cur++)
	{
		if (block[cur] != 0 || run == 15){
			generate_counters (run, block[cur], ac_counts);
			if (block[cur] != 0) i++;
			run = 0;
		}
		else run++;
	}
	
	if (cur<64) generate_counters (0, 0, ac_counts);
	return EXIT_SUCCESS;
}

int generate_counters (unsigned char run, short level, int* ac_counts)
{	
	char bc = 0;
	short mg = 0;
	bcmg (level, &bc, &mg);
	ac_counts[bc*16 + run]++;	
	return EXIT_SUCCESS;
}







