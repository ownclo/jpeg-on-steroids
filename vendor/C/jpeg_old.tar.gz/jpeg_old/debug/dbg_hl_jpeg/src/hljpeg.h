#define SIZE 8
#include "../include/bitstream.h"
#include "../include/huffman.h"
#include "../include/low_lvl_jpeg.h"
#include <math.h>

/*---------DCT-----------*/
double calcelm (double x[SIZE], double T[SIZE][SIZE], int i);
int dct_vec(double x[SIZE], double T[SIZE][SIZE], double y[SIZE]);
int dct_mat (double A[SIZE][SIZE], double B[SIZE][SIZE], double R[SIZE][SIZE]);
int genbasis (double T[SIZE][SIZE], double Tt[SIZE][SIZE]);
int printmat (double mat[SIZE][SIZE]);
int printvec (double vec[SIZE]);
int dct_test (void);
// pretty auto-documentation names, I believe. See ./dct.c for further information

/*-------QUANTUM----------*/
short roun (double num);													// round a double number
int quantum (double* inp, short* q, short* outp);							// outp = round(inp/q)
int quantum_test (double* input);


/*-------ZIGZAG-----------
int zigzag (short* in, short* out);
int zig_test (short* norm);*/

/*--------BCMG------------*/
char bc (short num);														// Computing bit category of num
int bcmg (short number, char* bcn, short* mg);
int bcmg_test (void);

/*--------RLE-------------*/
int rle (short* block, REZP cd_ac, 											// RLE of the ZZ block
		 unsigned int* output, int* current_cell, int* freeplace);			// output data
		 
int generate (unsigned char run, short level, REZP cd_ac, 					// Encode a (Run, LvL) pair.
			  unsigned int* output, int* current_cell, int* freeplace);

/*------ENTROPHY----------*/												// Encoding of a block
int entrophy (short* zigzagged, short* dcprev, REZP cd_dc, REZP cd_ac, 
			  unsigned int* output, int* current_cell, int* freeplace);
			  
int get_number_of_blocks (DCTDATA* data);
int counters_dc (short int* data, int* dc_counts, int n);
int counters_ac (short int* data, int* ac_counts, int n);
int rle_counters (short* block, int* ac_counts);
int generate_counters (unsigned char run, short level, int* ac_counts);

/*-------HIGH LEVEL--------*/
int coder (FILE* stream, short int* data, unsigned int* output, int n);		// Entrophy coding of an image. HL function interface.
int decode_component (FILE* stream, short* dataDCT, int Blks);				// Entrophy decoding of an image.   
int main_coder (void);
int main_decoder (void);

