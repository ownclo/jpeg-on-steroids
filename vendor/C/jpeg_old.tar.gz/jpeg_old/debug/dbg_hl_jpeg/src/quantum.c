#include <stdio.h>
#include <stdlib.h>
#include "./hljpeg.h"
short roun (double num)
{
	short k = (short) num;
	return ((short) (num + num)) - k;
}

int quantum (double* inp, short* q, short* outp)
{	
	int i;
	short qua;
	short y;
	short m;
	short sign;
	for (i = 0; i < SIZE*SIZE; i++){
		y = roun(inp[i]);
		qua = q[i];
		m = qua>>1;
		sign = ((y>>31)&1);										// 0 if positive, 1 if negative.
		
		outp[i] = (y + m*(!sign) - m*sign)/qua;
	}
	return 1; 
}

int quantum_test (double* input)
{
	printf("-----------------------------------\nSTARTING TESTs OF THE QUANTUM MODULE\n");
	short* rez;
	short* quant;
	int k = 1;														// k for flexibility of compression.
	rez = (short*) malloc(SIZE*SIZE*sizeof(short));
	quant = (short*) malloc(SIZE*SIZE*sizeof(short));
	int i, j;
	for(i = 0; i < SIZE; i++){
		for(j=0; j<SIZE; j++){
			quant[i*SIZE+j] = 1 + k*(i + j); }}
	
	quantum(input, quant, rez);
	for(i = 0; i < SIZE*SIZE; i++) 
		printf("%f\t%d\t%d\n", input[i], quant[i], rez[i]);
	printf("\n");
	free(rez);
	free(quant);
	return 1;
}	

