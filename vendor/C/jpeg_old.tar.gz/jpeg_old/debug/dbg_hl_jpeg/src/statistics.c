#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double psnr (unsigned char* s1, unsigned char* s2, int w, int h)
{
    double esn;
    int i, j;
    double k;
    long int sum = 0;
    long int tmpsq;

    k = w * h * (((1<<7)-1)<<9 + 1); // (1<<A) - (1<<B) <=> ((1<<(A-B))-1)<<B
    for (i = 0; i < h; i++){
	for (j = 0; j < w; j++){
	    tmpsq = (long int) (s1[i*w+j] - s2[i*w+j]);
	    sum = sum + tmpsq*tmpsq;
	}
    }
    printf("%f\n", (double) sum);
    k = k/((double) sum);
    k = log(k)/log(10);
    return 10*k;
}

int main (void)
{
    unsigned char s1[1000000];
//    unsigned char s2[12] = {35, 32, 31, 30, 29, 35, 36, 20, 31, 34, 56, 30};
    unsigned char s2[1000000];
    int w = 1000;
    int h = 1000;
    double psn;
    int i;
    for (i = 0; i < 1000000; i++)
    {
    	s1[i] = i;
    	s2[i] = i + 10;
    }

    psn = psnr (s1, s2, w, h);
    printf ("%f\n", psn);

    return EXIT_SUCCESS;
}

