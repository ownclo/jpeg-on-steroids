/* HERE AND NOW, GENTLEMEN, I WILL WORK UPON THE FUNCTION OF THE ZIGZAGONAL TRANSFORMATION OF AN 2-DIM ARRAY */

/* The core function takes a pointer of a 1-dim array, and return another one */


#include <stdio.h>
#include <stdlib.h>
//#include "./hljpeg.h"

#define SIZE 8
#define UP -1
#define DOWN 1
#define STEP (SIZE - 1)


int zigzag (short* in, short* out)
{
	int i,k,t,s;
	int where;
	char dir;

	dir = DOWN;
	out[0] = 0;
	out[1] = 1;

	s = 1; i = 2;

	for (k = 1; k < STEP; k++) {
		for (t = 0; t < k; t++){
			s += STEP*dir; //printf("%d\n", s);
			out[i] = s;
			i++;
		}
		where = !((dir & 2) >> 1); 		// 1 if we are going DOWN, 0 if UP
		s += where * SIZE + !where * 1;
		out[i] = s; i++;
		dir *= -1;
	}
	for (k = STEP; k > 0; k--){
		for (t = 0; t < k; t++){
			s += STEP*dir;
			out[i] = s; i++;
		}
		where = (dir & 2) >> 1;  		// 0 if we are going DOWN, 1 if UP
		s += where * SIZE + !where * 1;
		out[i] = s; i++;
		dir *= -1;
	}
	return 1;
}


int zig_test (short* norm)
{
	printf("-----------------------------------\nSTARTING TESTs OF THE ZIGZAG MODULE\n");
	short zigz[SIZE*SIZE];
	short perm[SIZE*SIZE];			/* this is a permutation array. simple */
	short perm_rev[SIZE*SIZE];
	int i, j;
	zigzag(norm, perm);				/* generating a permutational array */
	for (i = 0; i < SIZE*SIZE; i++){
		printf ( ((i&7 == 0) ? "%d\n" : "%d "), perm[i]);
	}
	j = 0;
	printf("\n");
	for (i = 0; i < SIZE*SIZE; i++){
		while (perm[j]!=i) j++;
		perm_rev[i] = j;
		printf("%d ", perm_rev[i]);
		j = 0;}
	printf("\n");
	for (i = 0; i < SIZE*SIZE; i++){
		zigz[i] = norm[(int)perm[i]]; }
	return 1;
}

int main (void)
{
	short* perm;
	perm = (short*) calloc (64, sizeof(short));
	zig_test (perm);
	return 1;
}




		
			
