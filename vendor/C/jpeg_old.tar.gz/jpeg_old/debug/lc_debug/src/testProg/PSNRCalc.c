#include <stdlib.h>
#include <stdio.h>
#include "../lib/bmpjpeg.h"

int main(int argc, char *argv[])
{
  PDRGB *in = NULL, *out = NULL;
  PDCBCR *inY = NULL, *outY = NULL;

  if( argc < 2 )
    {
      (void)puts("No arguments provided!");
      return EXIT_FAILURE;
    }
  
  in = getRGBFromFile(argv[1]);
  out = getRGBFromFile(argv[2]);

  inY = RGBtoCBCR(in);
  outY = RGBtoCBCR(out);

  testPSNROnLena(inY, outY);

  testPSNRforRGB(in, out);

  freeCBCR(inY);
  freeCBCR(outY);

  freeRGB(in);
  freeRGB(out);

  return EXIT_SUCCESS;
}
