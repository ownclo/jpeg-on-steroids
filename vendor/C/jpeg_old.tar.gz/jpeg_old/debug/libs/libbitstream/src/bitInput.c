#include "./bitstream.h"
/* Aperture Science Laboratories */
/* See the headerfile './bitstream.h' for the documentation */
unsigned int getbits (unsigned int* stream, int* cellnum, int* bitnum, int length)
{
	unsigned int rez;

	if ( *bitnum >= length )
	{
		rez = (stream[*cellnum] >> (*bitnum - length)) & ((1 << length) - 1);
		*bitnum = *bitnum - length;
		if (*bitnum == 0)
		{
			*cellnum = *cellnum + 1;
			*bitnum = 32;
		}
	}
	else
	{
		rez = ((stream[*cellnum] & ((1 << *bitnum) - 1)) << (length - *bitnum)) | (stream[*cellnum + 1] >> (32 - length + *bitnum));
		*cellnum = *cellnum + 1;
		*bitnum = 32 - length + *bitnum;
	}
	return rez;
}
