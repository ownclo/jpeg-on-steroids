#include "./bitstream.h"
/* Aperture Science Laboratories */
/* That function writes 'numbits' of 'bits' into a 'buffer'['cur'] position, considering that there is 'freeplace' of free bits in that cell */
 
int putbits (unsigned int bits, unsigned int numbits, unsigned int* buffer, int* cur, int* freeplace)
{
	int t;
	t = *freeplace - ((int) numbits);
	unsigned int pt = bits;
	if (t >= 0)
	{
		buffer[*cur] = buffer[*cur] | (bits << t);
		*freeplace -= numbits;
		if (*freeplace == 0)
		{
			*cur = *cur + 1;
			*freeplace = 32;
		}
	}
	else
	{
		buffer[*cur] = buffer[*cur] | (pt >> (-1*t));
		t = 32 + t;
		*cur = *cur + 1;
		*freeplace = 32;
		putbits ((((1 << (-1 * (t- 32))) - 1) & bits),			// else add to the nest cell
			 (-1 * (t - 32)), 								// the rest of bits
			 buffer, 
			 cur,
			 freeplace);	
	}
	return 1;
}
