/* Aperture Science Laboratololory */
/* This is a library of basic binary stream input/output routines */


/*---------------------------------*/
/* Bit outputing routine */
/* Put 'numbits' of bits from 'bits' to the 'cur' cell of 'buffer', wich has 'freeplace' of unoccuped bits */
/* At the start of the routine, 'cur' must be set as 0, 'freeplace' as 32 */
int putbits (unsigned int bits, unsigned int numbits, unsigned int* buffer, int* cur, int* freeplace);
/*---------------------------------*/


/*---------------------------------*/
/* Bit inputing routine */
/* Gets 'length' bits from the 'stream' in a 'cellnum' cell and 'bitnum' position */
/* At the start of the routine, 'cellnum' must be 0, 'bitnum' must be 32 */
unsigned int getbits (unsigned int* stream, int* cellnum, int* bitnum, int length);
/*---------------------------------*/
