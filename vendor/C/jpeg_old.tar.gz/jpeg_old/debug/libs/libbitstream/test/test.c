#include <stdio.h>
#include <stdlib.h>
#include <bitstream.h>

int main (void)
{
	unsigned int* buffer;
	unsigned int gotit;
	buffer = (unsigned int*) malloc (5*sizeof(unsigned int));
	int cur = 0;
	int freeplace = 32;
	int getcell = 0;
	int getbitn = 32;
	
	putbits (5, 3, buffer, &cur, &freeplace);
	gotit = getbits (buffer, &getcell, &getbitn, 3);
	
	printf("%d\n", (unsigned int) buffer[0]); 
	printf("%d\n", (unsigned int)  gotit);
	return EXIT_SUCCESS;
}
