#include <stdlib.h>
#include <memory.h>
#include <malloc.h>
#include <stdio.h>
#include <limits.h>
#include "bmpjpeg.h"
#include "matr.h"
#include "constants.h"

const char PERM_MAT[64] = {0, 1, 8, 16, 9, 2, 3, 10,
			   17, 24, 32, 25, 18, 11, 4, 5,
			   12, 19, 26, 33, 40, 48, 41, 34,
			   27, 20, 13, 6, 7, 14, 21, 28,
			   35, 42, 49, 56, 57, 50, 43, 36,
			   29, 22, 15, 23, 30, 37, 44, 51,
			   58, 59, 52, 45, 38, 31, 39, 46,
			   53, 60, 61, 54, 47, 55, 62, 63};

const char REV_PERM_MAT[64] = {0, 1, 5, 6, 14, 15, 27, 28,
			       2, 4, 7, 13,16, 26, 29, 42,
			       3, 8,12, 17,25, 30, 41, 43,
			       9, 11, 18, 24, 31, 40, 44, 53,
			       10, 19, 23, 32, 39, 45, 52, 54,
			       20, 22, 33, 38, 46, 51, 55, 60,
			       21, 34, 37, 47, 50, 56, 59, 61,
			       35, 36, 48, 49, 57, 58, 62, 63};

short QUANT_MAT[64] = {32};

void shrtTodbl(short *src, double *dest)
{
  unsigned int i = 0;
  if( src != NULL && dest != NULL )
    {
      for(i;i < 64; i++)
	*(dest + i) = (double) *(src + i);
    }
  else
    {
      (void)puts(PRONULL);
      return;
    }
}

void dblToshrt( double *src, short *dest)
{
  unsigned int i = 0;
  if( src != NULL && dest != NULL )
    {
      for(i;i < 64; i++)
	*(dest + i) = (short) *(src + i);
    }
  else
    {
      (void)puts(PRONULL);
      return;
    }
}

short roun (double num)
{
	short k = (short) num;
	return ((short) (num + num)) - k;
}

short *quantum( const double* inp)
{
  int i = 0;
  short qua = 0, y = 0, m = 0, sign = 0;
  short *out = NULL;

  out = malloc(sizeof(short)<<6);

  if(!out)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out, 0, sizeof(short)<<6);

  for (i = 0; i < 64; i++)
    {
      y = roun( *(inp + i) );
      qua = QUANT_MAT[i];
      m = qua>>1;
      sign = ((y>>31)&1);
      *(out + i) = (y + m*(!sign) - m*sign)/qua;
    }

  return out;
}

void zigzag (short* in, short* out)
{
	int i,k,t,s;
	int where;
	char dir;

	if( !in || !out )
	  {
	    (void)puts(PRONULL);
	    return;
	  }

	dir = DOWN;
	out[0] = 0;
	out[1] = 1;

	s = 1; i = 2;

	for (k = 1; k < STEP; k++) {
		for (t = 0; t < k; t++){
			s += STEP*dir; /* printf("%d\n", s); */
			out[i] = s;
			i++;
		}
		where = !((dir & 2) >> 1); 		/* 1 if we are going DOWN, 0 if UP */
		s += where * VECLEN + !where * 1;
		out[i] = s; i++;
		dir *= -1;
	}
	for (k = STEP; k > 0; k--){
		for (t = 0; t < k; t++){
			s += STEP*dir;
			out[i] = s; i++;
		}
		where = (dir & 2) >> 1;  		/* 0 if we are going DOWN, 1 if UP */
		s += where * VECLEN + !where * 1;
		out[i] = s; i++;
		dir *= -1;
	}
	return;
}

#ifdef DEBUG
void genrateSpec(const double *in)
{
  
}
#endif

PDRGB *getRGBFromFile(const char *fName)
{
  FILE *I = NULL;
  BMPHEADER bmpHeader;
  BMPINFOHEADER bmpInfoHeader;
  PDRGB *out = NULL;
  unsigned int i = 0;

  if(!fName)
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if( !(I = fopen(fName,"rb")) )
    {
      (void)puts(NOFOPENREAD);
      return NULL;
    }

  (void)fread(&bmpHeader, sizeof(BMPHEADER), 1, I);
  (void)fread(&bmpInfoHeader, sizeof(BMPINFOHEADER), 1, I);

  if( bmpHeader.type != BMPTYPE )
    {
      (void)puts(NOBMP);
      (void)fclose(I);
      return NULL;
    }

  out = malloc(sizeof(PDRGB));

  if( !out )
    {
      (void)puts(NOMEM);
      (void)fclose(I);
      return NULL;
    }

  (void)memset(out, 0, sizeof(PDRGB) );
  out->data = malloc(sizeof(BMPPIX8BNA) * bmpInfoHeader.width * bmpInfoHeader.height);

  if( !out->data )
    {
      (void)puts(NOMEM);
      (void)free(out);
      (void)fclose(I);
      return NULL;
    }
  (void)memset(out->data, 0, sizeof(BMPPIX8BNA) * bmpInfoHeader.width * bmpInfoHeader.height);

  out->dBytes = (4 - ((bmpInfoHeader.width * sizeof(BMPPIX8BNA))&3))&3;

  for(i = 0; i < bmpInfoHeader.height; i++)
    {
      (void)fread(out->data + i * bmpInfoHeader.width, sizeof(BMPPIX8BNA), bmpInfoHeader.width, I);
      (void)fseek(I, out->dBytes, SEEK_CUR);
    }

  out->w = bmpInfoHeader.width;
  out->h = bmpInfoHeader.height;

  (void)fclose(I);
  return out;
}

/* Returns pointer to image in YCbCr colorspace */
PDCBCR *RGBtoCBCR(const PDRGB *in)
{
/* Initialising variables */
  PDCBCR *output = NULL;
  unsigned char mvX = 0, mvY = 0;
  unsigned int i = 0, j = 0, k = 0, l = 0;

/* Validity test */
  if( !in )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if(!in->data)
    {
      (void)puts(PRONULL);
      return NULL;
    }

  output = malloc(sizeof(PDCBCR));

  if(!output)
  {
    (void)puts(NOMEM);
    return NULL;
  }

  (void)memset(output, 0, sizeof(PDCBCR));

  output->Ydata = malloc(sizeof(short)*in->w*in->h);
  if(!output->Ydata)
  {
    (void)puts(NOMEM);
    (void)free(output);
    return NULL;
  }
  (void)memset(output->Ydata, 0, sizeof(short)*in->w*in->h);

  output->CbData = malloc(sizeof(short)*((in->w + (in->w&1))*(in->h + (in->h&1)))>>2);
  if(!output->CbData)
  {
    (void)puts(NOMEM);
    (void)free(output->Ydata);
    (void)free(output);
    return NULL;
  }
  (void)memset(output->CbData, 0, sizeof(short)*((in->w + (in->w&1))*(in->h + (in->h&1)))>>2);

  output->CrData = malloc(sizeof(short)*((in->w + (in->w&1))*(in->h + (in->h&1)))>>2);
  if(!output->CrData)
  {
    (void)puts(NOMEM);
    (void)free(output->Ydata);
    (void)free(output->CbData);
    (void)free(output);
    return NULL;
  }
  (void)memset(output->CrData, 0, sizeof(short)*((in->w + (in->w&1))*(in->h + (in->h&1)))>>2);

  /* Calculating Cb & Cr components */

  for(i=0;i<in->h;i+=2)
    {
      for(j=0;j<in->w;j+=2)
	{
	
	  mvY = ( (i + 1) < (in->h) ) ? ( 1 ) : ( 0 );
	  mvX = ( (j + 1) < (in->w) ) ? ( 1 ) : ( 0 );
	
	  *(output->CbData + l*((in->w + (in->w&1))>>1) + k) = ((short)( CB * ((in->data + i*in->w + j)->B - (YR * (in->data + i*in->w + j)->R + YG * (in->data + i*in->w + j)->G + YB * (in->data + i*in->w + j)->B) ) + CB * ((in->data + i*in->w + j + mvX)->B - (YR * (in->data + i*in->w + j + mvX)->R + YG * (in->data + i*in->w + j + mvX)->G + YB * (in->data + i*in->w + j + mvX)->B) ) + CB * ((in->data + (i + mvY)*in->w + j)->B - (YR * (in->data + (i + mvY)*in->w + j)->R + YG * (in->data + (i + mvY)*in->w + j)->G + YB * (in->data + (i + mvY)*in->w + j)->B) ) + CB * ((in->data + (i + mvY)*in->w + j + mvX)->B - (YR * (in->data + (i + mvY)*in->w + j + mvX)->R + YG * (in->data + (i + mvY)*in->w + j + mvX)->G + YB * (in->data + (i + mvY)*in->w + j + mvX)->B) ) + 512 ))>>2;
	  *(output->CrData + l*((in->w + (in->w&1))>>1) + k) = ((short)( CR * ((in->data + i*in->w + j)->R - (YR * (in->data + i*in->w + j)->R + YG * (in->data + i*in->w + j)->G + YB * (in->data + i*in->w + j)->B) ) + CR * ((in->data + i*in->w + j + mvX)->R - (YR * (in->data + i*in->w + j + mvX)->R + YG * (in->data + i*in->w + j + mvX)->G + YB * (in->data + i*in->w + j + mvX)->B) ) + CR * ((in->data + (i + mvY)*in->w + j)->R - (YR * (in->data + (i + mvY)*in->w + j)->R + YG * (in->data + (i + mvY)*in->w + j)->G + YB * (in->data + (i + mvY)*in->w + j)->B) ) + CR * ((in->data + (i + mvY)*in->w + j + mvX)->R - (YR * (in->data + (i + mvY)*in->w + j + mvX)->R + YG * (in->data + (i + mvY)*in->w + j + mvX)->G + YB * (in->data + (i + mvY)*in->w + j + mvX)->B) ) + 512 ))>>2;
	  k++;
	}
      k = 0;
      l++;
    }

  /* Calculating Y component */

  for(i=0;i<in->h;i++)
    {
      for(j=0;j<in->w;j++)
	{
	  *(output->Ydata + j + i*(in->w)) = (in->data + j + i*(in->w))->R * YR + (in->data + j + i*(in->w))->G * YG + (in->data + j + i*(in->w))->B * YB;
	}
    }

  output->w = in->w;
  output->h = in->h;
  output->dBytes = in->dBytes;

  return output;
}

/* Returns pointer to image in RGB colorspace */
PDRGB *CBCRtoRGB(const PDCBCR *in)
{
  /* Initialising variables */
  PDRGB *output = NULL;
  unsigned int i = 0, j = 0, k = 0, l = 0;
  short tmpVal = 0;
  unsigned char mvX = 0, mvY = 0;

  /* Validity checks */
  if( !in || !(in->Ydata) || !(in->CbData) || !(in->CrData))
    {
      (void)puts(PRONULL);
      return NULL;
    }

  output = malloc(sizeof(PDRGB));
  if( !output )
    {
      (void)puts(NOMEM);
      return NULL;
    }
  (void)memset(output, 0, sizeof(PDRGB));

  output->data = malloc(sizeof(BMPPIX8BNA)*in->w * in->h);
  if( !(output->data) )
    {
      (void)puts(NOMEM);
      (void)free(output);
      return NULL;
    }
  (void)memset(output->data, 0, sizeof(BMPPIX8BNA)*in->w * in->h);

  for(i = 0;i < in->h; i+=2)
    {
      for(j = 0;j < in->w; j+=2)
	{

	  mvY = ( (i + 1) < (in->h) ) ? ( 1 ) : ( 0 );
	  mvX = ( (j + 1) < (in->w) ) ? ( 1 ) : ( 0 );

	  /* Calculating G components for block of 4 pixels, clipping */

	  tmpVal = *(in->Ydata + i * in->w + j) + YCR * (*(in->CrData + l + k * ((in->w + (in->w&1))>>1)) - 128) + YCB * (*(in->CbData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + j + i * in->w)->G = tmpVal;

	  tmpVal = *(in->Ydata + i * in->w + j + mvX) + YCR * (*(in->CrData + l + k * ((in->w + (in->w&1))>>1)) - 128) + YCB * (*(in->CbData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j + mvX)->G = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j) + YCR * (*(in->CrData + l + k * ((in->w + (in->w&1))>>1)) - 128) + YCB * (*(in->CbData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j)->G = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j + mvX) + YCR * (*(in->CrData + l + k * ((in->w + (in->w&1))>>1)) - 128) + YCB * (*(in->CbData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j + mvX)->G = tmpVal;

	  /* Calculating red components for block of 4 pixels, clipping*/

	  tmpVal = *(in->Ydata + i * in->w + j) + RCR * (*(in->CrData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j)->R = tmpVal;

	  tmpVal = *(in->Ydata + i * in->w + j + mvX) + RCR * (*(in->CrData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j + mvX)->R = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j) + RCR * (*(in->CrData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j)->R = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j + mvX) + RCR * (*(in->CrData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j + mvX)->R = tmpVal;

	  /* Calculating blue components for block of 4 pixels, clipping */

	  tmpVal = *(in->Ydata + i * in->w + j) + BCR * (*(in->CbData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j)->B = tmpVal;

	  tmpVal = *(in->Ydata + i * in->w + j + mvX) + BCR * (*(in->CbData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j + mvX)->B = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j) + BCR * (*(in->CbData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j)->B = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j + mvX) + BCR * (*(in->CbData + l + k * ((in->w + (in->w&1))>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j + mvX)->B = tmpVal;
	  l++;
	}
      k++;
      l = 0;
    }

  output->w = in->w;
  output->h = in->h;
  output->dBytes = in->dBytes;

  return output;
}

void writeToBMP(const char *fName, const PDRGB *dataToWrite)
{
  FILE *O = NULL;
  BMPHEADER bmpHeader;
  BMPINFOHEADER bmpInfoHeader;
  unsigned int i = 0, dBytes = (4 - ((bmpInfoHeader.width * sizeof(BMPPIX8BNA))&3))&3;;

 

  if( !fName || !dataToWrite || !(dataToWrite->data) )
    {
      (void)puts(PRONULL);
      return;
    }

  O = fopen(fName, "wb");

  if( !O )
    {
      (void)puts(NOFOPENWRITE);
      return;
    }

  bmpHeader.type = BMPTYPE;
  bmpHeader.size = sizeof(BMPHEADER) + sizeof(BMPINFOHEADER) + (dataToWrite->w * 3 + dBytes)*dataToWrite->h;
  bmpHeader.reserved1 = 0;
  bmpHeader.reserved2 = 0;
  bmpHeader.offset = sizeof(BMPHEADER) + sizeof(BMPINFOHEADER);

  bmpInfoHeader.size = sizeof(BMPINFOHEADER);
  bmpInfoHeader.width = dataToWrite->w;
  bmpInfoHeader.height = dataToWrite->h;
  bmpInfoHeader.planes = 1;
  bmpInfoHeader.bits = 24;
  bmpInfoHeader.compression = 0;
  bmpInfoHeader.imagesize = (dataToWrite->w*3 + dBytes) * dataToWrite->h;
  bmpInfoHeader.xresolution = 2834;
  bmpInfoHeader.yresolution = 2834;
  bmpInfoHeader.ncolors = 0;
  bmpInfoHeader.importantcolors = 0;

  (void)fwrite(&bmpHeader, sizeof(BMPHEADER), 1, O);
  (void)fwrite(&bmpInfoHeader, sizeof(BMPINFOHEADER), 1, O);

  for(i = 0; i < dataToWrite->h; i++)
    {
      (void)fwrite( dataToWrite->data + i*(dataToWrite->w), sizeof(BMPPIX8BNA), dataToWrite->w, O);
      (void)fwrite( dataToWrite , sizeof(unsigned char), dBytes, O);
    }

  (void)fclose(O);
  return;

}

/* Returns quantized, DCT'ed block of YCbCr */
short *getDCTedBlock(unsigned char blkType, unsigned int blkNum, const PDCBCR *in)
{
  short *out = NULL, *result = NULL;
  matriceD *cosMat = NULL, *cosMatT = NULL, *valBlk = NULL, *cosMatN = NULL, *matTemp = NULL, *matTemp2 = NULL;
  unsigned int i = 0, j = 0, xBlk = 0, yBlk = 0, xCBlk = 0, yCBlk = 0, skipX = 0, skipY = 0;

  if( !in || !(in->Ydata) || !(in->CbData) || !(in->CrData) )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if( (blkType != YTYPE) && (blkType != CBTYPE) && (blkType != CRTYPE) )
    {
      (void)puts(INVARG);
      (void)puts("e");
      return NULL;
    }

  if( blkType == YTYPE && blkNum > ( ( (in->w & 7) == 0 ) ? ( in->w>>3 ) : ( (in->w>>3) + 1 ) ) * ( ( (in->h & 7) == 0 ) ? ( in->h>>3 ) : ( (in->h>>3) + 1 ) ) )
    {
      (void)puts(INVARG);
      (void)puts("w");
      return NULL;
    }

  if( (blkType == CRTYPE || blkType == CBTYPE) && blkNum > ( ( ((in->w>>1) & 7) == 0 ) ? ( in->w>>4 ) : ( (in->w>>4) + 1 ) ) * ( ( ((in->h>>1) & 7) == 0 ) ? ( in->h>>4 ) : ( (in->h>>4) + 1 ) ) )
    {
      (void)puts(INVARG);
      (void)puts("q");
      return NULL;
    }

  valBlk = matMakeD( VECLEN, VECLEN);

  xBlk = ( (in->w & 7) == 0 ) ? ( in->w>>3 ) : ( ( in->w>>3 ) + 1 );
  yBlk = ( (in->h & 7) == 0 ) ? ( in->h>>3 ) : ( ( in->h>>3 ) + 1 );

  xCBlk = ( (( in->w>>1 ) & 7) == 0 ) ? ( in->w>>4 ) : ( ( in->w>>4 ) + 1 );
  yCBlk = ( (( in->h>>1 ) & 7) == 0 ) ? ( in->h>>4 ) : ( ( in->h>>4 ) + 1 );

  skipX = ( blkType == YTYPE ) ? ( blkNum % xBlk ) : ( blkNum % xCBlk );
  skipY = ( blkType == YTYPE ) ? ( blkNum / yBlk ) : ( blkNum / yCBlk );

  for(j = 0;j < VECLEN;j++)
    {
      for(i = 0;i < VECLEN;i++)
	{
	  switch(blkType)
	    {
	      case YTYPE:
		*(valBlk->ptr + i + j*VECLEN) = ( ((skipX<<3) + i > in->w) || (skipY<<3) + j > in->h ) ? (0) : ( *( in->Ydata + (skipX<<3) + ((skipY*in->w)<<3) + j*in->w + i ) );
		break;
	      case CBTYPE:
		*(valBlk->ptr + i + j*VECLEN) = ( ((skipX<<3) + i > in->w>>1) || (skipY<<3) + j > in->h>>1 ) ? (0) : ( *( in->CbData + (skipX<<3) + (((skipY<<3)*(in->w>>1))) + j*(in->w>>1) + i ) );
		break;
	      case CRTYPE:
		*(valBlk->ptr + i + j*VECLEN) = ( ((skipX<<3) + i > in->w>>1) || (skipY<<3) + j > in->h>>1 ) ? (0) : ( *( in->CrData + (skipX<<3) + (((skipY<<3)*(in->w>>1))) + j*(in->w>>1) + i ) );
		break;
	    }
	}
    }

  /* Doing DCT of our block */

  cosMat = prepDCT();
  cosMatT = matTranspondD(cosMat);
  cosMatN = matGenNormD();

  matTemp = matMultD(cosMat, cosMatN);
  matKillD(cosMat);
  cosMat = matTemp;

  matTemp = matMultD(cosMatT, cosMatN);
  matKillD(cosMatT);
  matKillD(cosMatN);
  cosMatT = matTemp;

  matTemp = matMultD(cosMat, valBlk);
  matTemp2 = matMultD(matTemp, cosMatT);


  matKillD(valBlk);
  valBlk = matTemp2;
  matKillD(matTemp);
  matKillD(cosMat);
  matKillD(cosMatT);

  /* Starting quantization of our block */

  out = quantum( valBlk->ptr );

  matKillD(valBlk);

  result = malloc( sizeof(short)<<6);
  (void)memset( result, 0, sizeof(short)<<6);

  for (i = 0; i < 64; i++)
    {
      result[i] = out[(int)PERM_MAT[i]];
    }

  (void)free(out);

  return result;

}

/* This function will return DCT'ed image as subsequent blocks */
DCTDATA *vomit(const PDCBCR *in, unsigned short qRate)
{
  /* Initialising variables */
  DCTDATA *out = NULL;
  unsigned int j = 0, i = 0, yBlks = 0, cBlks = 0;
  short *buf = NULL;

  /* Checking validity and allocating memory */
  if( !in || !(in->Ydata) || !(in->CrData) || !(in->CbData) )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  out = malloc(sizeof(DCTDATA));

  if( !out )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out, 0, sizeof(DCTDATA));

  i = ((in->w & 7) == 0) ? (in->w>>3) : ( (in->w>>3) + 1 );
  j = ((in->h & 7) == 0) ? (in->h>>3) : ( (in->h>>3) + 1 );

  yBlks = i*j;

  out->YdataDCT = malloc(sizeof(short)*(yBlks<<6));

  if( !out->YdataDCT )
    {
      (void)puts(NOMEM);
      (void)free(out);
      return NULL;
    }

  (void)memset(out->YdataDCT, 0, sizeof(short)*(yBlks<<6));

  i = ( ((in->w>>1) & 7) == 0) ? (in->w>>4) : ( (in->w>>4) + 1 );
  j = ( ((in->h>>1) & 7) == 0) ? (in->h>>4) : ( (in->h>>4) + 1 );

  cBlks = i*j;

  out->CbDataDCT = malloc(sizeof(short)*(cBlks<<6));

  if( !out->CbDataDCT )
    {
      (void)puts(NOMEM);
      (void)free(out->YdataDCT);
      (void)free(out);
      return NULL;
    }

  (void)memset(out->CbDataDCT, 0, sizeof(short)*(cBlks<<6));

  out->CrDataDCT = malloc(sizeof(short)*(cBlks<<6));

  if( !out->CrDataDCT )
    {
      (void)puts(NOMEM);
      (void)free(out->YdataDCT);
      (void)free(out->CbDataDCT);
      (void)free(out);
      return NULL;
    }

  (void)memset(out->CrDataDCT, 0, sizeof(short)*(cBlks<<6));

  /* Calculating quantization matrice for DCT */
  for(i = 0; i < VECLEN; i++)
    {
      for(j = 0; j< VECLEN; j++)
	{
	  QUANT_MAT[ (i<<3) + j] = ( 1 + qRate*(i + j) );
	}
    }

  for(i = 0; i < yBlks;i++)
    {
      buf = getDCTedBlock(YTYPE,i,in);
      (void)memcpy(out->YdataDCT + (i<<6), buf, sizeof(short)<<6);
      (void)free(buf);
    }

  for(i = 0; i < cBlks;i++)
    {
      buf = getDCTedBlock(CBTYPE,i,in);
      (void)memcpy(out->CbDataDCT + (i<<6), buf, sizeof(short)<<6);
      (void)free(buf);
    }

  for(i = 0; i < cBlks;i++)
    {
      buf = getDCTedBlock(CRTYPE,i,in);
      (void)memcpy(out->CrDataDCT + (i<<6), buf, sizeof(short)<<6);
      (void)free(buf);
    }

  out->YBlks = yBlks;
  out->CBlks = cBlks;
  out->w = in->w;
  out->h = in->h;

  return out;
}

/*
short *IDCTOneBlock(char blkType, unsigned int blkNum, DCTDATA *in)
{
  short *out = NULL, *buf = NULL;
  unsigned int i = 0;
  matriceD *cosMat = NULL, *cosMatT = NULL, *matNorm = NULL, *matTemp = NULL, *matData = NULL;

  if( !in )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if( blkType != YTYPE && blkType != CBTYPE && blkType != CRTYPE )
    {
      (void)puts(INVARG);
      return NULL;
    }

  out = malloc(sizeof(short)<<6);
  buf = malloc(sizeof(short)<<6);
  (void)memset(out, 0, sizeof(short) * in->w * in->h);

  cosMat = prepDCT();
  cosMatT = matTranspondD(cosMat);
  matNorm = matGenNormD();
  matTemp = matMultD( cosMat, matNorm );

  matKillD( cosMat );
  cosMat = matTemp;

  matTemp = matMultD( cosMatT, matNorm );

  matKillD( cosMatT );
  cosMatT = matTemp;

  matKillD( matNorm );

  matData = malloc(sizeof(matriceD));
  matData->x = VECLEN;
  matData->y = VECLEN;

  switch( blkType )
    {
      case (YTYPE):
	if( blkNum > in->YBlks )
	  {
	    (void)puts(INVARG);
	    (void)free(out);
	    return NULL;
	  }
	
	matData->ptr = in->YdataDCT + (blkNum<<6);
	
	matTemp = matMultD(cosMatT , matData);
	matNorm = matMultD(matTemp , cosMat );
	
	matKillD( matTemp );
	dblToshrt( &buf, matNorm->ptr);
	matKillD( matNorm );
	
	for (i = 0; i < 64; i++)
	  {
	    out[i] = buf[(int)REV_PERM_MAT[i]];
	  }
	break;
      case (CBTYPE):
	if( blkNum > in->CBlks )
	  {
	    (void)puts(INVARG);
	    (void)free(out);
	    return NULL;
	  }
	break;
      case (CRTYPE):
	if( blkNum > in->CBlks )
	  {
	    (void)puts(INVARG);
	    (void)free(out);
	    return NULL;
	  }
	break;
    }
  return out;
}
*/

PDCBCR *returnFromDCT( DCTDATA *data )
{
  short *buf = NULL, *res = NULL, *yBuf = NULL, *cbBuf = NULL, *crBuf = NULL;
  PDCBCR *out = NULL;
  matriceD *cosMat = NULL, *cosMatNorm = NULL, *cosMatT = NULL, *tmpDCTMat = NULL, *dataMat = NULL, *step1 = NULL, *step2 = NULL;
  unsigned int YblksXSize = 0, YblksYSize = 0, CblksXSize = 0, CblksYSize = 0, j = 0, i = 0, l = 8, k = 8, skipX = 0, skipY = 0, xBlk = 0, yBlk = 0, xCBlk = 0, yCBlk = 0;

  if(!data || !data->YdataDCT || !data->CbDataDCT || !data->CrDataDCT )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  cosMat = prepDCT();
  cosMatT = matTranspondD(cosMat);
  cosMatNorm = matGenNormD();

  tmpDCTMat = matMultD(cosMatT, cosMatNorm);
  matKillD(cosMatT);
  cosMatT = tmpDCTMat;

  tmpDCTMat = matMultD(cosMat, cosMatNorm);
  matKillD(cosMat);
  cosMat = tmpDCTMat;

  matKillD(cosMatNorm);

  YblksXSize = ((data->w & 7) == 0) ? (data->w>>3) : ( (data->w>>3) + 1);
  YblksYSize = ((data->h & 7) == 0) ? (data->h>>3) : ( (data->h>>3) + 1);

  CblksXSize = ( (((data->w>>1) + (data->w & 1)) & 7) == 0 ) ? ( ((data->w>>1) + (data->w & 1))>>3 ) : ( (((data->w>>1) + (data->w & 1))>>3) + 1 );
  CblksYSize = ( (((data->h>>1) + (data->h & 1)) & 7) == 0 ) ? ( ((data->h>>1) + (data->h & 1))>>3 ) : ( (((data->h>>1) + (data->h & 1))>>3) + 1 );

  dataMat = matMakeD( VECLEN, VECLEN);
  out = malloc(sizeof(PDCBCR));
  (void)memset(out, 0, sizeof(PDCBCR));
  out->Ydata = malloc(sizeof(short) * data->w * data->h );
  (void)memset(out->Ydata, 0, sizeof(short) * data->w * data->h);
  yBuf = malloc( (sizeof(short)<<6) * data->YBlks );
  (void)memset( yBuf, 0, (sizeof(short)<<6) * data->YBlks);

  res = malloc(sizeof(short)<<6);
  (void)memset(res, 0, sizeof(short)<<6);
  buf = malloc(sizeof(short)<<6);
  (void)memset(buf, 0, sizeof(short)<<6);

  for( i = 0; i < data->YBlks; i++)
    {

      for(j = 0; j < 64; j++)
	{
	  *(res + j) = *(data->YdataDCT + REV_PERM_MAT[j] + (i<<6));
	}

      shrtTodbl( res, dataMat->ptr);
      cosMatNorm = matMultD( cosMatT, dataMat );
      tmpDCTMat = matMultD( cosMatNorm, cosMat );
      matKillD( cosMatNorm );
      dblToshrt( tmpDCTMat->ptr, buf );
      matKillD(tmpDCTMat);

      (void)memcpy(yBuf + (i<<6), buf, sizeof(short)<<6 );
    }

  skipX = (YblksXSize<<3) - data->w;
  skipY = (YblksYSize<<3) - data->h;

  for(i = 0; i < data->h>>1; i++)
    {
      for(j = 0; j < data->w>>1; j++)
	{
	  *(out->Ydata + j + i * data->w) = *(yBuf + ((j>>3)<<6) + (j&7) + ((i&7)<<3) + ((i>>3)<<3) );
	}
    }

  out->CbData = malloc(sizeof(short) * ( (data->w>>1) + (data->w&1)) * ( (data->h>>1) + (data->h&1)) );
  (void)memset(out->CbData, 0, sizeof(short) * ( (data->w>>1) + (data->w&1)) * ( (data->h>>1) + (data->h&1)));

  cbBuf = malloc( (sizeof(short)<<6) * data->CBlks );
  (void)memset( cbBuf, 0, (sizeof(short)<<6) * data->CBlks);

  for( i = 0; i < data->CBlks; i++)
    {

      for(j = 0; j < 64; j++)
	{
	  *(res + j) = *(data->CbDataDCT + REV_PERM_MAT[j] + (i<<6));
	}

      shrtTodbl( res, dataMat->ptr);
      cosMatNorm = matMultD( cosMatT, dataMat );
      tmpDCTMat = matMultD( cosMatNorm, cosMat );
      matKillD( cosMatNorm );
      dblToshrt( tmpDCTMat->ptr, buf );
      matKillD(tmpDCTMat);

      (void)memcpy(cbBuf + (i<<6), buf, sizeof(short)<<6 );
    }

  for(i = 0; i < data->h>>1; i++)
    {
      for(j = 0; j < data->w>>1; j++)
	{
	  *(out->Ydata + j + i * (data->w>>1) ) = *(cbBuf + ((j>>3)<<6) + (j&7) + ((i&7)<<3) + ((i>>3)<<3) );
	}
    }

  out->CrData = malloc(sizeof(short) * ( (data->w>>1) + (data->w&1)) * ( (data->h>>1) + (data->h&1)) );
  (void)memset(out->CrData, 0, sizeof(short) * ( (data->w>>1) + (data->w&1)) * ( (data->h>>1) + (data->h&1)));

  crBuf = malloc( (sizeof(short)<<6) * data->CBlks );
  (void)memset( crBuf, 0, (sizeof(short)<<6) * data->CBlks);

  for( i = 0; i < data->CBlks; i++)
    {

      for(j = 0; j < 64; j++)
	{
	  *(res + j) = *(data->CrDataDCT + REV_PERM_MAT[j] + (i<<6));
	}

      shrtTodbl( res, dataMat->ptr);
      cosMatNorm = matMultD( cosMatT, dataMat );
      tmpDCTMat = matMultD( cosMatNorm, cosMat );
      matKillD( cosMatNorm );
      dblToshrt( tmpDCTMat->ptr, buf );
      matKillD(tmpDCTMat);

      (void)memcpy(crBuf + (i<<6), buf, sizeof(short)<<6 );
    }

  out->w = data->w;
  out->h = data->h;

  matKillD(cosMat);
  matKillD(cosMatT);
  matKillD(dataMat);
  (void)free(yBuf);
  (void)free(cbBuf);
  (void)free(crBuf);
  (void)free(res);
  (void)free(buf);

  return out;
}

/* Frees the current RGB block */
void freeRGB(PDRGB *in)
{
  if(in != NULL)
    {
      if(in->data != NULL)
	{
	  (void)free(in->data);
	}
      (void)free(in);
    }
}

/* Frees the current YCbCr block */
void freeCBCR(PDCBCR *in)
{
  if(in != NULL)
    {
      if(in->Ydata != NULL)
        {
          (void)free(in->Ydata);
        }
      if(in->CbData != NULL)
        {
          (void)free(in->CbData);
        }
      if(in->CrData != NULL)
        {
          (void)free(in->CrData);
        }
      (void)free(in);
    }
}

void freeDCT(DCTDATA *in)
{
  if(in != NULL)
    {
      if(in->YdataDCT != NULL)
	{
	  (void)free(in->YdataDCT);
	}
      if(in->CbDataDCT != NULL)
	{
	  (void)free(in->CbDataDCT);
	}
      if(in->CrDataDCT != NULL)
	{
	  (void)free(in->CrDataDCT);
	}
      (void)free(in);
    }
}
