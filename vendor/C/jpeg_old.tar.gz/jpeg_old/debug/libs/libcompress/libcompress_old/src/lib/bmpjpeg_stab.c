#include <stdlib.h>
#include <memory.h>
#include <malloc.h>
#include <stdio.h>
#include <limits.h>
#include "bmpjpeg.h"
#include "matr.h"

short roun (double num)
{
	short k = (short) num;
	return ((short) (num + num)) - k;
}

short *quantum( const double* inp, const short* qRate)
{
  int i = 0;
  short qua = 0, y = 0, m = 0, sign = 0;
  short *out = NULL;

  out = malloc(sizeof(short)<<6);

  if(!out)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out, 0, sizeof(short)<<6);

  for (i = 0; i < 64; i++)
    {
      y = roun( *(inp + i) );
      qua = *(qRate + i);
      m = qua>>1;
      sign = ((y>>31)&1);
      *(out + i) = (y + m*(!sign) - m*sign)/qua;
    }

  return out;
}

#ifdef DEBUG
void genrateSpec(const double *in)
{
  
}
#endif

PDRGB *getRGBFromFile(const char *fName)
{
  FILE *I = NULL;
  BMPHEADER head;
  BMPINFOHEADER ihead;
  PDRGB *out = NULL;
  unsigned int i = 0;
  unsigned char dummyBs = 0;

  if( fName != NULL)
    {
      I = fopen(fName,"rb");
      
      if(I != NULL)
	{
	  (void)fseek(I,0,SEEK_SET);
	  (void)fread(&head, sizeof(BMPHEADER), 1, I);
	  if( head.type == BMPTYPE )
	    {
	      (void)fread(&ihead, sizeof(BMPINFOHEADER), 1, I);
	      out = malloc(sizeof(PDRGB));
	      if( out != NULL)
		{
		  dummyBs = (ihead.width*3) % 4;
		  out->w = ihead.width;
		  out->h = ihead.height;
		  out->realW = ihead.width;
		  out->realH = ihead.height;
		  
		  out->data = malloc(sizeof(PDRGB)*out->w*out->h);
		  
		  for(i = 0; i < ihead.height; i++)
		    {
		      (void)fread(out->data + i*(out->w), sizeof(BMPPIX8BNA), ihead.width, I);
		      (void)fseek(I, dummyBs, SEEK_CUR);
/*		      if(ihead.width&1)
		        {
		          (void)memcpy(out->data + (i+1)*(ihead.width) + i*(ihead.width&1), out->data + (i+1)*(ihead.width) + i*(ihead.width&1) - 1, sizeof(PDRGB));
		        }*/
		    }
		  /*
		  if(ihead.height&1)
		    {
		      (void)memcpy(out->data + ihead.height*(ihead.width + (ihead.width&1)), out->data + (ihead.height - 1)*(ihead.width + (ihead.width&1)), sizeof(PDRGB)*(ihead.width + (ihead.width&1)));
		    }*/
		  
		  printf("%d",dummyBs);
		  (void)fclose(I);
		  return out;
		}
	      else
		{
		  (void)puts(NOMEM);
		  (void)fclose(I);
		}
	    }
	  else
	    {
	      (void)puts(NOBMP);
	      (void)fclose(I);
	    }
	}
      else
	{
	  (void)puts(NOFOPEN);
	}
    }
  else
    {
      (void)puts(PRONULL);
    }

  return NULL;
}

/* Returns pointer to image in YCbCr colorspace */
PDCBCR *RGBtoCBCR(const PDRGB *in)
{
/* Initialising variables */
  PDCBCR *output = NULL;
  unsigned char mvX = 0, mvY = 0;
  unsigned int i = 0, j = 0, k = 0, l = 0;
  short tmpY = 0;

/* Validity test */
  if( !in )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if(!in->data)
    {
      (void)puts(PRONULL);
      return NULL;
    }

  output = malloc(sizeof(PDCBCR));

  if(!output)
  {
    (void)puts(NOMEM);
    return NULL;
  }

  (void)memset(output, 0, sizeof(PDCBCR));

  output->Ydata = malloc(sizeof(short)*in->w*in->h);
  if(!output->Ydata)
  {
    (void)puts(NOMEM);
    (void)free(output);
    return NULL;
  }
  (void)memset(output->Ydata, 0, sizeof(short)*in->w*in->h);

  output->CbData = malloc(sizeof(short)*(in->w*in->h)>>2);
  if(!output->CbData)
  {
    (void)puts(NOMEM);
    (void)free(output->Ydata);
    (void)free(output);
    return NULL;
  }
  (void)memset(output->CbData, 0, sizeof(short)*(in->w*in->h)>>2);

  output->CrData = malloc(sizeof(short)*(in->w*in->h)>>2);
  if(!output->CrData)
  {
    (void)puts(NOMEM);
    (void)free(output->Ydata);
    (void)free(output->CbData);
    (void)free(output);
    return NULL;
  }
  (void)memset(output->CrData, 0, sizeof(short)*(in->w*in->h)>>2);

  /* Calculating Cb & Cr components */

  for(i=0;i<in->h;i+=2)
    {
      for(j=0;j<in->w;j+=2)
	{
	
	  mvY = ( (i + 1) >= (in->h) ) ? ( 0 ) : ( 1 );
	  mvX = ( (j + 1) >= (in->w) ) ? ( 0 ) : ( 1 );
	
	  *(output->CbData + l*(in->w>>1) + k) = ((short)( CB * ((in->data + i*in->w + j)->B - (YR * (in->data + i*in->w + j)->R + YG * (in->data + i*in->w + j)->G + YB * (in->data + i*in->w + j)->B) ) + CB * ((in->data + i*in->w + j + mvX)->B - (YR * (in->data + i*in->w + j + mvX)->R + YG * (in->data + i*in->w + j + mvX)->G + YB * (in->data + i*in->w + j + mvX)->B) ) + CB * ((in->data + (i + mvY)*in->w + j)->B - (YR * (in->data + (i + mvY)*in->w + j)->R + YG * (in->data + (i + mvY)*in->w + j)->G + YB * (in->data + (i + mvY)*in->w + j)->B) ) + CB * ((in->data + (i + mvY)*in->w + j + mvX)->B - (YR * (in->data + (i + mvY)*in->w + j + mvX)->R + YG * (in->data + (i + mvY)*in->w + j + mvX)->G + YB * (in->data + (i + mvY)*in->w + j + mvX)->B) ) + 512 ))>>2;
	  *(output->CrData + l*(in->w>>1) + k) = ((short)( CR * ((in->data + i*in->w + j)->R - (YR * (in->data + i*in->w + j)->R + YG * (in->data + i*in->w + j)->G + YB * (in->data + i*in->w + j)->B) ) + CR * ((in->data + i*in->w + j + mvX)->R - (YR * (in->data + i*in->w + j + mvX)->R + YG * (in->data + i*in->w + j + mvX)->G + YB * (in->data + i*in->w + j + mvX)->B) ) + CR * ((in->data + (i + mvY)*in->w + j)->R - (YR * (in->data + (i + mvY)*in->w + j)->R + YG * (in->data + (i + mvY)*in->w + j)->G + YB * (in->data + (i + mvY)*in->w + j)->B) ) + CR * ((in->data + (i + mvY)*in->w + j + mvX)->R - (YR * (in->data + (i + mvY)*in->w + j + mvX)->R + YG * (in->data + (i + mvY)*in->w + j + mvX)->G + YB * (in->data + (i + mvY)*in->w + j + mvX)->B) ) + 512 ))>>2;
	  k++;
	}
      k = 0;
      l++;
    }

  /* Calculating Y component */

  for(i=0;i<in->h;i++)
    {
      for(j=0;j<in->w;j++)
	{
	  *(output->Ydata + j + i*(in->w)) = (in->data + j + i*(in->w))->R * YR + (in->data + j + i*(in->w))->G * YG + (in->data + j + i*(in->w))->B * YB;
	}
    }

  output->decRate = 4;
  output->w = in->w;
  output->h = in->h;
  output->realH = in->realH;
  output->realW = in->realW;

  return output;
}

/* Returns pointer to image in RGB colorspace */
PDRGB *CBCRtoRGB(const PDCBCR *in)
{
  /* Initialising variables */
  PDRGB *output = NULL;
  unsigned int i = 0, j = 0, k = 0, l = 0;
  short tmpVal = 0;
  unsigned char mvX = 0, mvY = 0;

  /* Validity checks */
  if( !in || !(in->Ydata) || !(in->CbData) || !(in->CrData))
    {
      (void)puts(PRONULL);
      return NULL;
    }

  output = malloc(sizeof(PDRGB));
  if( !output )
    {
      (void)puts(NOMEM);
      return NULL;
    }
  (void)memset(output, 0, sizeof(PDRGB));

  output->data = malloc(sizeof(BMPPIX8BNA)*in->w * in->h);
  if( !(output->data) )
    {
      (void)puts(NOMEM);
      (void)free(output);
      return NULL;
    }
  (void)memset(output->data, 0, sizeof(BMPPIX8BNA)*in->w * in->h);

  for(i = 0;i < in->h; i+=2)
    {
      for(j = 0;j < in->w; j+=2)
	{

	  mvY = ( (i + 1) >= (in->h) ) ? ( 0 ) : ( 1 );
	  mvX = ( (j + 1) >= (in->w) ) ? ( 0 ) : ( 1 );

	  /* Calculating G components for block of 4 pixels, clipping */

	  tmpVal = *(in->Ydata + i * in->w + j) + YCR * (*(in->CrData + l + k * (in->w>>1)) - 128) + YCB * (*(in->CbData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + j + i * in->w)->G = tmpVal;

	  tmpVal = *(in->Ydata + i * in->w + j + mvX) + YCR * (*(in->CrData + l + k * (in->w>>1)) - 128) + YCB * (*(in->CbData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j + mvX)->G = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j) + YCR * (*(in->CrData + l + k * (in->w>>1)) - 128) + YCB * (*(in->CbData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j)->G = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j + mvX) + YCR * (*(in->CrData + l + k * (in->w>>1)) - 128) + YCB * (*(in->CbData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j + mvX)->G = tmpVal;

	  /* Calculating red components for block of 4 pixels, clipping*/

	  tmpVal = *(in->Ydata + i * in->w + j) + RCR * (*(in->CrData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j)->R = tmpVal;

	  tmpVal = *(in->Ydata + i * in->w + j + mvX) + RCR * (*(in->CrData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j + mvX)->R = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j) + RCR * (*(in->CrData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j)->R = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j + mvX) + RCR * (*(in->CrData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j + mvX)->R = tmpVal;

	  /* Calculating blue components for block of 4 pixels, clipping */

	  tmpVal = *(in->Ydata + i * in->w + j) + BCR * (*(in->CbData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j)->B = tmpVal;

	  tmpVal = *(in->Ydata + i * in->w + j + mvX) + BCR * (*(in->CbData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + i * in->w + j + mvX)->B = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j) + BCR * (*(in->CbData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j)->B = tmpVal;

	  tmpVal = *(in->Ydata + (i + mvY) * in->w + j + mvX) + BCR * (*(in->CbData + l + k * (in->w>>1)) - 128);
	  if(tmpVal > UCHAR_MAX)
	    {
	      tmpVal = UCHAR_MAX;
	    }
	  else if(tmpVal < 0)
	    {
	      tmpVal = 0;
	    }
	  (output->data + (i + mvY) * in->w + j + mvX)->B = tmpVal;
	  l++;
	}
      k++;
      l = 0;
    }

  output->w = in->w;
  output->h = in->h;
  output->realH = in->realH;
  output->realW = in->realW;

  return output;
}

void writeToBMP(const char *fName, const PDRGB *dataToWrite)
{
  /* Initialising variable */
  FILE *O = NULL;
  BMPHEADER head;
  BMPINFOHEADER iHeader;
  unsigned int i = 0;
  unsigned char dummyBs = 0;

  /* Checking validity of input */
  if( !fName || !dataToWrite || !(dataToWrite->data))
    {
      (void)puts(PRONULL);
      return;
    }

  O = fopen(fName, "wb");
  (void)fseek(O, 0, SEEK_SET);
  /* Initialising headers */

  dummyBs = (dataToWrite->realW*3) % 4;

  head.type = BMPTYPE;
  head.size = dataToWrite->realH*dataToWrite->realW*3 + sizeof(BMPHEADER) + sizeof(BMPINFOHEADER) + dummyBs*dataToWrite->realH;
  head.reserved1 = 0;
  head.reserved2 = 0;
  head.offset = sizeof(BMPHEADER) + sizeof(BMPINFOHEADER);

  iHeader.size = sizeof(BMPINFOHEADER);
  iHeader.width = dataToWrite->realW;
  iHeader.height = dataToWrite->realH;
  iHeader.planes = 1;
  iHeader.bits = 24;
  iHeader.compression = 0;
  iHeader.imagesize = dataToWrite->realH * dataToWrite->realW * 3 + dummyBs*dataToWrite->realH;
  iHeader.yresolution = iHeader.height;
  iHeader.xresolution = iHeader.width;
  iHeader.ncolors = 0;
  iHeader.importantcolors = 0;

  (void)fwrite(&head, sizeof(BMPHEADER), 1, O);
  (void)fwrite(&iHeader, sizeof(BMPINFOHEADER), 1, O);

  for(i = 0;i < dataToWrite->realH; i++)
    {
      (void)fwrite(dataToWrite->data + i*(dataToWrite->w), sizeof(BMPPIX8BNA), dataToWrite->realW, O);
      (void)fwrite(&dummyBs, sizeof(unsigned char), dummyBs, O);
    }

  (void)fclose(O);
}

/* Returns quantized, DCT'ed block of YCbCr */
short *getDCTedBlock(unsigned char blkType, unsigned int blkNum, unsigned char qRate, const PDCBCR *in)
{
  short *out = NULL, *quant = NULL;
  matriceD *cosMat = NULL, *cosMatT = NULL, *valBlk = NULL, *cosMatN = NULL, *matTemp = NULL, *matTemp2 = NULL;
  unsigned int i = 0, j = 0, xBlk = 0, yBlk = 0, xCBlk = 0, yCBlk = 0, skipX = 0, skipY = 0;

  if( !in || !(in->Ydata) || !(in->CbData) || !(in->CrData) )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if( (blkType != YTYPE) && (blkType != CBTYPE) && (blkType != CRTYPE) )
    {
      (void)puts(INVARG);
      (void)puts("e");
      return NULL;
    }

  if( blkType == YTYPE && blkNum > ( ( in->w % 8 == 0 ) ? ( in->w>>3 ) : ( (in->w>>3) + 1 ) ) * ( ( in->h % 8 == 0 ) ? ( in->h>>3 ) : ( (in->h>>3) + 1 ) ) )
    {
      (void)puts(INVARG);
      (void)puts("w");
      return NULL;
    }

  if( (blkType == CRTYPE || blkType == CBTYPE) && blkNum > ( ( (in->w>>1) % 8 == 0 ) ? ( in->w>>4 ) : ( (in->w>>4) + 1 ) ) * ( ( (in->h>>1) % 8 == 0 ) ? ( in->h>>4 ) : ( (in->h>>4) + 1 ) ) )
    {
      (void)puts(INVARG);
      (void)puts("q");
      return NULL;
    }

  valBlk = matMakeD( VECLEN, VECLEN);

  xBlk = ( in->w % 8 == 0 ) ? ( in->w>>3 ) : ( ( in->w>>3 ) + 1 );
  yBlk = ( in->h % 8 == 0 ) ? ( in->h>>3 ) : ( ( in->h>>3 ) + 1 );

  xCBlk = ( ( in->w>>1 ) % 8 == 0 ) ? ( in->w>>4 ) : ( ( in->w>>4 ) + 1 );
  yCBlk = ( ( in->h>>1 ) % 8 == 0 ) ? ( in->h>>4 ) : ( ( in->h>>4 ) + 1 );

  skipX = ( blkType == YTYPE ) ? ( blkNum % xBlk ) : ( blkNum % xCBlk );
  skipY = ( blkType == YTYPE ) ? ( blkNum % yBlk ) : ( blkNum % yCBlk );

  for(j = 0;j < VECLEN;j++)
    {
      for(i = 0;i < VECLEN;i++)
	{
	  switch(blkType)
	    {
	      case YTYPE:
		*(valBlk->ptr + i + j*VECLEN) = ( ((skipX<<3) + i > in->w) || (skipY<<3) + j > in->h ) ? (0) : ( *( in->Ydata + (skipX<<3) + ((skipY*in->w)<<3) + i*in->w + j ) );
		break;
	      case CBTYPE:
		*(valBlk->ptr + i + j*VECLEN) = ( ((skipX<<3) + i > in->w>>1) || (skipY<<3) + j > in->h>>1 ) ? (0) : ( *( in->CbData + (skipX<<3) + (((skipY<<3)*(in->w>>1))) + i*(in->w>>1) + j ) );
		break;
	      case CRTYPE:
		*(valBlk->ptr + i + j*VECLEN) = ( ((skipX<<3) + i > in->w>>1) || (skipY<<3) + j > in->h>>1 ) ? (0) : ( *( in->CrData + (skipX<<3) + (((skipY<<3)*(in->w>>1))) + i*(in->w>>1) + j ) );
		break;
	    }
	}
    }

  /* Doing DCT of our block */

  cosMat = prepDCT();
  cosMatT = matTranspondD(cosMat);
  cosMatN = matGenNormD();

  matTemp = matMultD(cosMat, cosMatN);
  matKillD(cosMat);
  cosMat = matTemp;

  matTemp = matMultD(cosMatT, cosMatN);
  matKillD(cosMatT);
  matKillD(cosMatN);
  cosMatT = matTemp;

  matTemp = matMultD(cosMat, valBlk);
  matTemp2 = matMultD(matTemp, cosMatT);


  matKillD(valBlk);
  valBlk = matTemp2;
  matKillD(matTemp);
  matKillD(cosMat);
  matKillD(cosMatT);

  /* Starting quantization of our block */

  quant = malloc(sizeof(short)<<6);

  if(!quant)
    {
      (void)puts(NOMEM);
      matKillD(matTemp2);
      (void)free(out);
      return NULL;
    }

  (void)memset(quant, 0, sizeof(short)<<6);

  for(i = 0; i < VECLEN; i++)
    {
      for(j=0; j< VECLEN; j++)
        {
	  *(quant + (i<<3) + j) = ( 1 + qRate*(i + j) );
        }
    }

  out = quantum( valBlk->ptr, quant);

  matKillD(valBlk);
  (void)free(quant);

  return out;

}

/* This function will return DCT'ed image as subsequent blocks */
DCTDATA *vomit(const PDCBCR *in, unsigned short qRate)
{
  /* Initialising variables */
  DCTDATA *out = NULL;
  unsigned int j = 0, i = 0, yBlks = 0, cBlks = 0;
  short *buf = NULL;

  /* Checking validity and allocating memory */
  if( !in || !(in->Ydata) || !(in->CrData) || !(in->CbData) )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  out = malloc(sizeof(DCTDATA));

  if( !out )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out, 0, sizeof(DCTDATA));

  i = (in->w % 8 == 0) ? (in->w>>3) : ( (in->w>>3) + 1 );
  j = (in->h % 8 == 0) ? (in->h>>3) : ( (in->h>>3) + 1 );

  yBlks = i*j;

  out->YdataDCT = malloc(sizeof(short)*(yBlks<<6));

  if( !out->YdataDCT )
    {
      (void)puts(NOMEM);
      (void)free(out);
      return NULL;
    }

  (void)memset(out->YdataDCT, 0, sizeof(short)*(yBlks<<6));

  i = ( (in->w>>1) % 8 == 0) ? (in->w>>4) : ( (in->w>>4) + 1 );
  j = ( (in->h>>1) % 8 == 0) ? (in->h>>4) : ( (in->h>>4) + 1 );

  cBlks = i*j;

  out->CbDataDCT = malloc(sizeof(short)*(cBlks<<6));

  if( !out->CbDataDCT )
    {
      (void)puts(NOMEM);
      (void)free(out->YdataDCT);
      (void)free(out);
      return NULL;
    }

  (void)memset(out->CbDataDCT, 0, sizeof(short)*(cBlks<<6));

  out->CrDataDCT = malloc(sizeof(short)*(cBlks<<6));

  if( !out->CrDataDCT )
    {
      (void)puts(NOMEM);
      (void)free(out->YdataDCT);
      (void)free(out->CbDataDCT);
      (void)free(out);
      return NULL;
    }

  (void)memset(out->CrDataDCT, 0, sizeof(short)*(cBlks<<6));

  for(i = 0; i < yBlks;i++)
    {
      buf = getDCTedBlock(YTYPE,i,qRate,in);
      (void)memcpy(out->YdataDCT + (i<<6), buf, sizeof(short)<<6);
      (void)free(buf);
    }

  for(i = 0; i < cBlks;i++)
    {
      buf = getDCTedBlock(CBTYPE,i,qRate,in);
      (void)memcpy(out->CbDataDCT + (i<<6), buf, sizeof(short)<<6);
      (void)free(buf);
    }

  for(i = 0; i < cBlks;i++)
    {
      buf = getDCTedBlock(CRTYPE,i,qRate,in);
      (void)memcpy(out->CrDataDCT + (i<<6), buf, sizeof(short)<<6);
      (void)free(buf);
    }

  return out;
}

/* Frees the current RGB block */
void freeRGB(PDRGB *in)
{
  if(in != NULL)
    {
      if(in->data != NULL)
	{
	  (void)free(in->data);
	}
      (void)free(in);
    }
}

/* Frees the current YCbCr block */
void freeCBCR(PDCBCR *in)
{
  if(in != NULL)
    {
      if(in->Ydata != NULL)
        {
          (void)free(in->Ydata);
        }
      if(in->CbData != NULL)
        {
          (void)free(in->CbData);
        }
      if(in->CrData != NULL)
        {
          (void)free(in->CrData);
        }
      (void)free(in);
    }
}

void freeDCT(DCTDATA *in)
{
  if(in != NULL)
    {
      if(in->YdataDCT != NULL)
	{
	  (void)free(in->YdataDCT);
	}
      if(in->CbDataDCT != NULL)
	{
	  (void)free(in->CbDataDCT);
	}
      if(in->CrDataDCT != NULL)
	{
	  (void)free(in->CrDataDCT);
	}
      (void)free(in);
    }
}
