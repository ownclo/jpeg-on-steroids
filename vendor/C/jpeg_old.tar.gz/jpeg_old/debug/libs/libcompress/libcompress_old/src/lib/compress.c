  /*
  libcompress - a static library with adaptive/non-adaptive huffman support 
  Written and debugged by Alexey Alexeevich Ponomarenko-Timofeev on 
  May 6 2012.
  */

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <malloc.h>
#include "bitWriter.h"
#include "compress.h"
#include "constants.h"

symbol symbols[257];
symbol *psymbols[257] = {NULL};

TREE_NODE_ENCODE *root = NULL;
TREE_NODE_DECODE *rootDe = NULL;

unsigned char isVis = F;
unsigned char leafs = 0;
unsigned short nodes = 0;

void initAll(void)
{
  unsigned short i = 0;
  
  root = malloc(sizeof(TREE_NODE_ENCODE));
  (void)memset(root, 0, sizeof(TREE_NODE_DECODE));
  for(i = 0; i<= 256; i++)
    {
      symbols[i].pOwner = NULL;
      symbols[i].count = 0;
      symbols[i].code = 0;
      symbols[i].codelength = 0;
      symbols[i].symbol = i;
    }
  root->ptr = &symbols[256];
  symbols[256].pOwner = (void *)root;
}

TREE_NODE_ENCODE *findBro(TREE_NODE_ENCODE *src,unsigned char mode)
{
  if(!src)
    {
      (void)puts("Error: Null provided in findBro function!");
      return NULL;
    }

  if( src == root )
    {
      return NULL;
    }

  if(src == src->up)
    {
      (void)puts("Error: tree is corrupted!");
      return NULL;
    }

  if(src->up->left == src)
    {
      return (mode == 'T') ? (src->up->right) : (src->up->left);
    }
  else
    {
      return (mode == 'R') ? (src->up->right) : (src->up->left);
    }

  (void)puts("Error: Unable to find bro in the tree, exiting!");
  return NULL;
}

void rebuildWeights(TREE_NODE_ENCODE *tmp)
{
  if(tmp != root)
  {
    do{
      tmp = tmp->up;
      tmp->weight++;
    }while(tmp != root);
  }
}

void rebuildTree(TREE_NODE_ENCODE *src)
{
  TREE_NODE_ENCODE *cPos=NULL, *sto1=NULL, *sto2=NULL, *tmp=NULL;
  unsigned char found = 0;
  unsigned int i = 0;

  if(src == NULL)
   {
    (void)puts("Error:NULL provided insted of pointer in rebuildTree!");
    return;
   }

  if(src == root || src->up == root)
    {
      return;
    }

  cPos = src->up;
  tmp = findBro(cPos, 'T');


  while(src != root && cPos != root)
    {
      while(src != root && cPos != root && tmp->weight <= src->weight)
	{
	  if(tmp->weight != src->weight)
	    {
	      sto1 = src;
	      sto2 = tmp;
	      found = 255;
	    }

	  cPos = cPos->up;

	  if(cPos != NULL && cPos != root)
	    {
	      tmp = findBro(cPos, 'T');
	    }
	}
      src = src->up;
      cPos = src->up;
      if(cPos != NULL && cPos != root)
        {
          tmp = findBro(cPos, 'T');
        }
    }

  if(found == 255 && sto1->weight != sto2->weight && sto1 != root && sto2 != root)
    {
      if(sto1->up->left == sto1)
	{
	  found++;
	}

      if(sto2->up->left == sto2)
	{
	  found = found + 2;
	}

      switch (found)
	{
	  case 255:
	    sto1->up->right = sto2;
	    sto2->up->right = sto1;
	    break;
	  case 0:
	    sto1->up->left = sto2;
	    sto2->up->right = sto1;
	    break;
	  case 1:
	    sto1->up->right = sto2;
	    sto2->up->left = sto1;
	    break;
	  case 2:
	    sto1->up->left = sto2;
	    sto2->up->left = sto1;
	    break;
	}

      cPos = sto1->up;
      sto1->up = sto2->up;
      sto2->up = cPos;

      i = abs(sto1->weight - sto2->weight);

      tmp = sto1;
      while(tmp != root)
	{
	  tmp = tmp->up;
	  tmp->weight += i;
        }

      tmp = sto2;
      while(tmp != root)
	{
	  tmp = tmp->up;
	  tmp->weight -= i;
	}
    }
}

void adaptCode(char *iName, char *oName)
{
  FILE *I = NULL, *O = NULL;
  unsigned int i = 0, fLen = 0, cPos = 0, onePercent = 0;
  unsigned char j = 0, tmp = 0;
  TREE_NODE_ENCODE *cEsc = root, *temp = NULL;

  if(!iName && !oName)
    {
      (void)puts("Error: NULL in filenames!\a");
      return;
    }

  I = fopen(iName, "rb");

  if( !I )
    {
       (void)puts("Error: Can't open file!\a");
       return;
    }

  O = fopen(oName, "wb");
  
  if(isVis == T)
    {
      (void)puts("Number of leafs is variable, no summary will be displayed.");
      (void)fseek(I,0,SEEK_END);
      fLen = ftell(I);
      (void)fseek(I,0,SEEK_SET);
      fLen -= ftell(I);
      onePercent = fLen/100;
    }
  else
    {
      (void)fseek(I,0,SEEK_SET);
    }
    
  while(!feof(I))
    {
      (void)fread(&tmp, sizeof(char), 1, I);
      i++;

      if(i - cPos >= onePercent && isVis == T)
      {
        (void)putchar('[');
        for(j=1;j<101;j+=2)
	  {
	    (j<=((double)i/(double)fLen * 100)) ? ((void)putchar('=')) : ((void)putchar(' '));
	  }
	(void)printf("] < %d%% >", (unsigned int)((double)i/(double)fLen * 100));
	(i < fLen - onePercent) ? (void)putchar('\r') : (void)puts("");
	cPos = i;
	(void)fflush(stdout);
      }

      if(symbols[tmp].pOwner == NULL)
	{
	  (void)writeBitArrayToFile(O, symbols[256].codelength, reverseBits( symbols[256].codelength, symbols[256].code) );
	  (void)writeBitArrayToFile(O, 8, tmp );
	  cEsc->right = malloc(sizeof(TREE_NODE_ENCODE));
	  cEsc->left = malloc(sizeof(TREE_NODE_ENCODE));
	  (void)memset(cEsc->right, 0, sizeof(TREE_NODE_ENCODE));
	  (void)memset(cEsc->left, 0, sizeof(TREE_NODE_ENCODE));
	  cEsc->right->up = cEsc->left->up = cEsc;
	  cEsc->left->ptr = &symbols[tmp];
	  cEsc->left->weight = symbols[tmp].count = 1;
	  cEsc->right->ptr = cEsc->ptr;
	  cEsc->ptr = NULL;
	  rebuildWeights(cEsc->left);
	  rebuildTree(cEsc->left);
	  (void)getCodes(root,0,0);
	  symbols[tmp].pOwner = (void *)cEsc->left;
	  cEsc = cEsc->right;
	  symbols[256].pOwner = (void *)cEsc;
	}
       else
	{
	  (void)writeBitArrayToFile(O, symbols[tmp].codelength, reverseBits(symbols[tmp].codelength, symbols[tmp].code) );
	  temp = (TREE_NODE_ENCODE*)symbols[tmp].pOwner;
	  temp->weight++;
	  symbols[tmp].count++;
	  rebuildWeights(temp);
	  rebuildTree(temp);
	  (void)getCodes(root,0,0);
	}
    }
  dumpBuffer(O);
  (void)fwrite(&i, sizeof(int), 1, O);
  (void)fclose(I);
  (void)fclose(O);
  end(root);
}

void adaptDecode(char *iName, char *oName)
{
  FILE *I = NULL, *O = NULL;
  unsigned int oSize =0, i = 2, cPos = 0, onePercent = 0;
  unsigned char tmp = 0, j = 0;
  TREE_NODE_ENCODE *temp = root, *cEsc = NULL;

  if(iName == NULL || oName == NULL)
    {
      (void)puts("ERROR: NULL provided in adaptDecode!");
      return;
    }

  if( (I = fopen(iName, "rb")) == NULL)
    {
      (void)puts("ERROR: Can't open input file.");
      return;
    }

  (void)fseek(I, -4, SEEK_END);
  (void)fread(&oSize,sizeof(int),1,I);
  (void)fseek(I, 0, SEEK_SET);

  if(isVis == T)
    {
      onePercent = oSize / 100;
    }

  O = fopen(oName, "wb");
  tmp = reverseBits(8, readBitsFromFile(I,8));
  cEsc = root;
  cEsc->left = malloc(sizeof(TREE_NODE_ENCODE));
  cEsc->right = malloc(sizeof(TREE_NODE_ENCODE));
  (void)memset(cEsc->left, 0, sizeof(TREE_NODE_ENCODE));
  (void)memset(cEsc->right, 0, sizeof(TREE_NODE_ENCODE));
  cEsc->right->up = cEsc->left->up = cEsc;
  cEsc->left->ptr = &symbols[tmp];
  cEsc->left->weight = cEsc->weight = symbols[tmp].count = 1;
  cEsc->right->ptr = cEsc->ptr;
  cEsc->ptr = NULL;
  symbols[tmp].pOwner = (void *)cEsc->left;
  symbols[256].pOwner = (void *)cEsc->right;
  (void)fwrite(&tmp, sizeof(char), 1, O);
  cEsc = cEsc->right;

  if(isVis == T)
    {
      (void)puts("Number of leafs is variable, no summary will be displayed.");
    }

  while(!feof(I) && i < oSize )
    {
      if(i - cPos >= onePercent && isVis == T)
      {
        (void)putchar('[');
        for(j=1;j<101;j+=2)
	  {
	    (j<=((double)i/(double)oSize * 100)) ? ((void)putchar('|')) : ((void)putchar(' '));
	  }
	(void)printf("] < %d%% >", (unsigned int)((double)i/(double)oSize * 100));
	(i < oSize - onePercent) ? (void)putchar('\r') : (void)puts("");
	cPos = i;
	(void)fflush(stdout);
      }

      tmp = readBitFromFile(I);
      (tmp == 1) ? (temp = temp->right) : (temp = temp->left);
      if( temp->ptr != NULL )
        {
          if( temp->ptr == &symbols[256] )
            {
              tmp = reverseBits(8, readBitsFromFile(I,8));
              cEsc->left = malloc(sizeof(TREE_NODE_ENCODE));
	      cEsc->right = malloc(sizeof(TREE_NODE_ENCODE));
	      (void)memset(cEsc->left, 0, sizeof(TREE_NODE_ENCODE));
	      (void)memset(cEsc->right, 0, sizeof(TREE_NODE_ENCODE));
	      cEsc->right->up = cEsc->left->up = cEsc;
	      cEsc->left->ptr = &symbols[tmp];
	      cEsc->left->weight = symbols[tmp].count = 1;
	      cEsc->right->ptr = cEsc->ptr;
	      cEsc->ptr = NULL;
	      symbols[tmp].pOwner = (void *)cEsc->left;
	      (void)fwrite(&tmp, sizeof(char), 1, O);
	      cEsc = cEsc->right;
	      symbols[256].pOwner = (void *)cEsc;
	    }
	  else
	    {
	      (void)fwrite(&temp->ptr->symbol, sizeof(char), 1, O);
	      tmp = temp->ptr->symbol;
	      temp->weight++;
	      symbols[tmp].count++;
     }
          rebuildWeights((TREE_NODE_ENCODE*)symbols[tmp].pOwner);
          rebuildTree((TREE_NODE_ENCODE*)symbols[tmp].pOwner);
          temp = root;
          i++;
        }
    }
  dumpBuffer(O);
  (void)fclose(I);
  (void)fclose(O);
  end(root);
}

void genFreq( char *fname )
{
	FILE *input = NULL;
        unsigned char buffer = 0;
	unsigned short i = 0;
	input = fopen(fname,"rb");

	if(input == NULL)
	  {
	    (void)puts("Error, can't open file!\a");
	    return;
	  }

	(void)fseek(input, 0, SEEK_SET);

	for(i = 0; i < 256; i++)
	  {
	    symbols[i].symbol = i;
	  }
	if(isVis == T)
	  {
            (void)puts("Gathering statistics...");
          }

	while(!feof(input))
	  {
	    (void)memset( &buffer, 0, sizeof(char));
	    (void)fread( &buffer, sizeof(char), 1, input);
	    symbols[buffer].count++;
	  }

	for(i = 0;i < 256; i++)
	  {
	     (symbols[i].count != 0) ? (psymbols[i] = &symbols[i]) : (psymbols[i] = NULL);
	  }

	(void)fclose(input);
	
	if(isVis == T)
	  {
            (void)puts("done.");
          }
}

void srtFreq( void )
{
	unsigned short i = 0,j = 0,mpos = 0;

	for(i = 0; i < 256; i++)
	  {
	    mpos = i;
	    for(j = i; j < 256; j++)
	      {
		if(symbols[j].count > symbols[mpos].count)
		  {
		    mpos = j;
		  }
	      }
	    if(mpos != i)
	      {
	        symbols[i].symbol = symbols[i].symbol ^ symbols[mpos].symbol;
	        symbols[mpos].symbol = symbols[mpos].symbol ^ symbols[i].symbol;
	        symbols[i].symbol = symbols[mpos].symbol ^ symbols[i].symbol;

	        symbols[i].count = symbols[i].count ^ symbols[mpos].count;
	        symbols[mpos].count = symbols[mpos].count ^ symbols[i].count;
	        symbols[i].count = symbols[mpos].count ^ symbols[i].count;

                psymbols[symbols[i].symbol] = &symbols[i];
		psymbols[symbols[mpos].symbol] = &symbols[mpos];
	      }
	  }

  for(i = 0;i < 256; i++)
    {
      if(psymbols[i]!=NULL)
	if(psymbols[i]->count == 0)
	  psymbols[i] = NULL;
    }
}

#ifdef DEBUG
void printDbgFreq( void )
{
	unsigned short i = 0;

	for(i = 0; i < 256; i++)
	  {
           if(psymbols[i] != NULL)
	     (void)printf("Symbol %d: %ld  -- %d  -- %d.\n\a", psymbols[i]->symbol, psymbols[i]->count, psymbols[i]->code, psymbols[i]->codelength);
	  }
	(void)puts("End.");
}
#endif

void buildTreeBase( void )
{
  short i = 0;

  TREE_NODE_ENCODE *temp = NULL, *temp2 = NULL;

  for(i = 0; symbols[i].count > 0; i++){}
  i = i - 1;
  leafs = i;

  if(i == 1 && symbols[i].count == 0)
  {
    (void)puts("Can't create tree base, maybe the file is empty?\n\a");
    return;
  }

  do
    {
      temp = malloc(sizeof(TREE_NODE_ENCODE));
      (void)memset( temp, 0, sizeof(TREE_NODE_ENCODE));
      temp->ptr = &symbols[i];
      temp->weight = symbols[i].count;
      temp->rarray = temp2;
      if(temp2 != NULL)
        {
          temp2->larray = temp;
        }
      temp2 = temp;
      i--;
    }while(i >= 0);

  root = temp;
}

TREE_NODE_ENCODE *getRightmost(void)
{
  TREE_NODE_ENCODE *temp = root;

  while(temp->rarray != NULL)
    {
      temp = temp->rarray;
    }

  return temp;
}

TREE_NODE_ENCODE *getLeftmost(void)
{
  TREE_NODE_ENCODE *temp = root;

  while(temp->larray != NULL)
    {
      temp = temp->larray;
    }

  return temp;
}

unsigned char isLeft(TREE_NODE_ENCODE *strt, TREE_NODE_ENCODE *tst)
{
  while(tst != NULL)
    {
      if(tst == strt)
	{
	  return F;
	}
      tst = tst->larray;
    }
  return T;
}

void interchange(TREE_NODE_ENCODE *p1, TREE_NODE_ENCODE *p2)
{
  TREE_NODE_ENCODE *temp1 = NULL, *temp2 = NULL;
  unsigned long weight = 0;
  symbol *symb = NULL;

  if(!p1 || !p2)
    {
      return;
    }

  weight = p1->weight;
  symb = p1->ptr;

  p1->weight = p2->weight;
  p1->ptr = p2->ptr;

  p2->ptr = symb;
  p2->weight = weight;

  temp1 = p1->left;
  temp2 = p1->right;

  p1->left = p2->left;
  p1->right = p2->right;

  p2->left = temp1;
  p2->right = temp2;
}

void srtPntrs( void )
{
  TREE_NODE_ENCODE *curMax = NULL, *cur = NULL, *temp = NULL;

  curMax = getLeftmost();

  if(!curMax->larray && !curMax->rarray)
    {
      return;
    }

  while( curMax != NULL )
    {
      temp = cur = curMax;
      while( cur != NULL )
	{
	  if(cur->weight > temp->weight)
	    {
	      temp = cur;
	    }
	  cur = cur->rarray;
	}
      if(temp != curMax)
        {
          interchange(temp, curMax);
        }
      curMax = curMax->rarray;
    }
}

void buildTree( void )
{
  TREE_NODE_ENCODE *newNode = NULL, *min1 = NULL, *min2 = NULL, *temp = NULL;

  if(isVis == T)
    {
      (void)puts("Building the Huffman tree...");
    }
    
  while( root->larray != NULL || root->rarray != NULL )
    {
      srtPntrs();
      min1 = temp = getRightmost();

      while( temp != NULL )
        {
          if(temp->weight < min1->weight)
            {
              min1 = temp;
            }
          temp = temp->larray;
        }

      min2 = getRightmost();
      if(min2 == min1)
	{
          if(min2->larray != NULL)
	    {
	      min2 = min2->larray;
	      goto foundLeft;
	    }
	  if(min2->rarray !=  NULL)
	    {
	      min2 = min2->rarray;
	    }
	  else
	    {
	      return;
	    }
	}

      foundLeft:

      temp = getRightmost();

      while(temp != NULL)
	{
	  if(temp->weight < min2->weight && temp != min1)
	    {
	      min2 = temp;
	    }
	  temp = temp->larray;
	}


      newNode = malloc(sizeof(TREE_NODE_ENCODE));
      (void)memset( newNode, 0, sizeof(TREE_NODE_ENCODE));

      nodes++;

      if(isLeft(min2, min1) == T)
        {
	  min1 = (TREE_NODE_ENCODE *)((unsigned long)min1 ^ (unsigned long)min2);
	  min2 = (TREE_NODE_ENCODE *)((unsigned long)min2 ^ (unsigned long)min1);
	  min1 = (TREE_NODE_ENCODE *)((unsigned long)min2 ^ (unsigned long)min1);
	}

      newNode->right = min1;
      newNode->left = min2;
      newNode->weight = newNode->right->weight + newNode->left->weight;

      if(min1->rarray != NULL)
	{
	  min1->rarray->larray = newNode;
          newNode->rarray = min1->rarray;
	}

      if(min2->larray != NULL)
	{
	  min2->larray->rarray = newNode;
	  newNode->larray = min2->larray;
	}

      root = newNode;
      temp = getLeftmost();
    }

  (void)getCodes(root,0,0);

  if(isVis == T)
    {
      (void)puts("done.");
    }
}

char getCodes( TREE_NODE_ENCODE *top,unsigned char depth, int codeSoFar )
{
  unsigned char leftDepth = 0, rightDepth = 0;

  if(top->ptr == NULL)
    {
      if(top->left != NULL)
	{
	  leftDepth = getCodes(top->left, depth+1, (codeSoFar<<1) );
	}
      if(top->right != NULL)
	{
	  rightDepth = getCodes(top->right, depth+1, (codeSoFar<<1)+1 );
	}
      return ((leftDepth < rightDepth) ?  rightDepth : leftDepth);
    }
  else
    {
      top->ptr->code = codeSoFar;
      top->ptr->codelength = depth;
      return depth;
    }
}

void writeTree( FILE *fout, TREE_NODE_ENCODE *cNode )
{
  if( !fout || !cNode)
    {
      (void)puts("Can't write tree to file, NULL provided.\a");
      return;
    }

  if(cNode == root && isVis == T)
    {
      (void)puts("Aquiring codes...");
    }

  if(cNode->ptr != NULL)
    {
      (void)writeBitToFile(fout, 0);
      (void)writeBitArrayToFile( fout, 8, cNode->ptr->symbol );
      return;
    }
  else
    {
      (void)writeBitToFile(fout, 1);
      writeTree( fout, cNode->left);
      writeTree( fout, cNode->right);
    }
  return;

  if(cNode == root && isVis == T)
    {
      (void)puts("done.");
    }
}

void writeToFile( char *inputName, char *outName)
{
  FILE *I = NULL,*O = NULL;
  unsigned char Ibuffer = 0;
  unsigned short i = 0;

  if(!inputName || !outName)
    {
      (void)puts("Error: NULL provided instead of string pointer.\n\a");
      return;
    }

  I = fopen(inputName, "rb");

  if(!I)
    {
      (void)puts("Error: Can't open input file!\n\a");
    }

  if(isVis == T)
    {
      (void)puts("Writing compressed data to file...");
    }

  O = fopen(outName, "wb");

  (void)fseek( I, 0, SEEK_SET);
  (void)fseek( O, 0, SEEK_SET);

  if(isVis == T)
    {
     (void)printf("Total size:%ld.\nNumber of leafs:%d.\nNumber of nodes:%d.\n", root->weight, leafs, nodes);
    }
    
  for(i = 0; i < 256; i++)
    {
      if(psymbols[i] != NULL)
	psymbols[i]->code = reverseBits(psymbols[i]->codelength, psymbols[i]->code);
    }

  (void)fwrite(&(root->weight), sizeof(int), 1, O);

  writeTree(O, root);

  while(!feof(I))
    {
      (void)fread(&Ibuffer, sizeof(char), 1, I);
      (void)writeBitArrayToFile(O, psymbols[Ibuffer]->codelength, psymbols[Ibuffer]->code);
    }

  dumpBuffer(O);

  (void)fclose(O);
  (void)fclose(I);

  if(isVis == T)
    {
     (void)puts("done.");
    }
    
  end(root);
}

void readTree(TREE_NODE_DECODE *ptr, FILE *I)
{
  unsigned char isEnd = 0;

  if(!ptr || !I)
    {
      (void)puts("Error: Can't decode, NULL provided.\n\a");
      return;
    }

  isEnd = readBitFromFile(I);

  if(isEnd == 0)
    {
      ptr->symbol = reverseBits(8 ,readBitsFromFile(I, 8));
      return;
    }
  else
    {
      ptr->left = malloc(sizeof(TREE_NODE_DECODE));
      (void)memset(ptr->left, 0, sizeof(TREE_NODE_DECODE));
      ptr->right = malloc(sizeof(TREE_NODE_DECODE));
      (void)memset(ptr->right, 0, sizeof(TREE_NODE_DECODE));
      ptr->symbol = 0;
      readTree(ptr->left,I);
      readTree(ptr->right, I);
      return;
    }

  if(isVis == T)
    {
      (void)puts("Huh?\n\a");
    }
}

void readFromFile(char *inName)
{
  FILE *I = NULL, *O = NULL;
  TREE_NODE_DECODE *temp1 = NULL;
  unsigned char i = 0;
  unsigned long j = 0, Olen = 0;

  I = fopen(inName,"rb");

  if(I == NULL)
    {
      return;
    }

  O = fopen("Output","wb");

  temp1 = malloc(sizeof(TREE_NODE_DECODE));
  (void)memset(temp1, 0, sizeof(TREE_NODE_DECODE));

  (void)fread( &Olen, sizeof(unsigned long), 1, I);

  if(isVis == T)
    {
      (void)puts("Reading Huffman tree from file...");
    }
  readTree(temp1, I);
  if(isVis == T)
    {
      (void)puts("done.");
    }

  rootDe = temp1;

  if(isVis == T)
    {
      (void)puts("Writing data to Output file...");
    }

  while(!feof(I) && j < Olen)
    {
      while(temp1->left != NULL && temp1->right != NULL)
	{
          i = readBitFromFile(I);
          if(i == 1)
	   {
	     temp1 = temp1->right;
	   }
          if(i == 0)
	   {
	     temp1 = temp1->left;
	   }
          if(feof(I))
           {
             return;
           }
	}
      (void)fwrite( &(temp1->symbol) ,sizeof(unsigned char), 1, O);
      j++;
      temp1 = rootDe;
    }

  if(isVis == T)
    {
      (void)puts("done.");
    }

  (void)fclose(I);
  (void)fclose(O);

  ende(rootDe);
}

void end( TREE_NODE_ENCODE *top )
{
  if(top != NULL)
    {
      end(top->left);
      end(top->right);
      (void)free(top);
    }
}

void ende( TREE_NODE_DECODE *top )
{
  if(top != NULL)
    {
      ende(top->left);
      ende(top->right);
      (void)free(top);
    }
}

void toggleVis(void)
{
  (isVis == T) ? (isVis = F) : (isVis = T);
}
