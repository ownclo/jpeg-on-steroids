#ifndef LIBCOMPRESS_H
#define LIBCOMPRESS_H

/* Struct for symbols array */

typedef struct symbol
{
  void *pOwner;
  unsigned long count;
  unsigned char symbol;
  unsigned int code;
  unsigned char codelength;
}symbol;

/* Needed while encoding with adaptive/non-adaptive Huffman */

typedef struct TREE_NODE_ENCODE
{
	struct TREE_NODE_ENCODE *up;
	struct TREE_NODE_ENCODE *left,*larray;
	unsigned long weight;
	symbol *ptr;
	struct TREE_NODE_ENCODE *right,*rarray;
}TREE_NODE_ENCODE;

/* Needed only to decode non-adaptive Huffman */

typedef struct TREE_NODE_DECODE
{
  struct TREE_NODE_DECODE *left, *right;
  unsigned char symbol;
}TREE_NODE_DECODE;

/* BELLS AND WHISTLES */

void toggleVis(void);

/* REQUIRED FOR BOTH */

char getCodes(TREE_NODE_ENCODE *top, unsigned char depth, int codeSoFar);

/* REQUIRED FOR ADAPTIVE HUFFMAN */

TREE_NODE_ENCODE *findBro(TREE_NODE_ENCODE *src,unsigned char mode);
void initAll(void);
void rebuildWeights(TREE_NODE_ENCODE *tmp);
void rebuildTree(TREE_NODE_ENCODE *src);
void adaptCode(char *iName, char *oName);
void adaptDecode(char *iName, char *oName);

/* REQUIRED FOR STATIC HUFFMAN */

void end(TREE_NODE_ENCODE *top);
void ende(TREE_NODE_DECODE *top);
void genFreq( char *fname );
void srtFreq( void );
#ifdef DEBUG
void printDbgFreq( void );
#endif
void buildTreeBase( void );
TREE_NODE_ENCODE *getRightmost(void);
TREE_NODE_ENCODE *getLeftmost(void);
unsigned char isLeft(TREE_NODE_ENCODE *strt, TREE_NODE_ENCODE *tst);
void interchange(TREE_NODE_ENCODE *p1, TREE_NODE_ENCODE *p2);
void srtPntrs( void );
void buildTree( void );
char getCodes( TREE_NODE_ENCODE *top,unsigned char depth, int codeSoFar );
void writeTree( FILE *fout, TREE_NODE_ENCODE *cNode );
void writeToFile( char *inputName, char *outName);
void readTree(TREE_NODE_DECODE *ptr, FILE *I);
void readFromFile(char *inName);
#endif
