#ifndef MATR_H
#define MATR_H

/* Struct for double matrice */
typedef struct matriceD
{
  unsigned short x,y;
  double *ptr;
}matriceD;

/* Struct for integer matrice */
typedef struct matriceI
{
  unsigned short x,y;
  int *ptr;
}matriceI;

/* UNUSED */
#ifdef DEBUG
void matMakeDNP(matriceD *ptr, unsigned short x, unsigned short y);
void matKillDNP(matriceD *ptr);
#endif

matriceD *matMakeD(unsigned short x, unsigned short y); /* Returns pointer to matrice with size x*y, exits if invalid size is passed or no memory */
matriceD *matTranspondD(const matriceD *in); /* Returns pointer to transponded matrice 'in', exits if NULL is passed or no memory */
matriceD *matAddD(const matriceD *M1,const matriceD *M2); /* Returns pointer to sum of matrices 'M1' & 'M2', exits if NULL is passed or no memory */
matriceD *matMultD(const matriceD *M1,const matriceD *M2); /* Returns pointer to product of matrices 'M1' & 'M2', exits if NULL is passed or no memory */
matriceD *matGenNormD(void);/* Returns pointer to normalizing matrice for DCT cosine matrice, exits if NULL is passed or no memory */
void matDispD(const matriceD *dis);/* Prints matrice 'in' to console, exits if NULL is passed */
double *matP2AD(const matriceD *dis);/* Returns pointer to linear array with matrice 'dis' content, exits if NULL is passed or no memory */
void matKillD(matriceD *vic);/* Frees matrice & contents */
matriceD *prepDCT(void);/* Prepare a matrice for DCT */
double getValAt(unsigned char x,unsigned char y, const matriceD *source );/* Obtain value from cell with x,y coordinates */

matriceI *matMakeI(unsigned short x, unsigned short y);/* Returns pointer to matrice with size x*y, exits if invalid size is passed or no memory */
matriceI *matTranspondI(const matriceI *in);/* Returns pointer to transponded matrice 'in', exits if NULL is passed or no memory */
matriceI *matAddI(const matriceI *M1,const matriceI *M2);/* Returns pointer to sum of matrices 'M1' & 'M2', exits if NULL is passed or no memory */
matriceI *matMultI(const matriceI *M1,const matriceI *M2);/* Returns pointer to product of matrices 'M1' & 'M2', exits if NULL is passed or no memory */
matriceI *matGenNormI(const matriceI *in);/* Returns pointer to normalizing matrice for matrice 'in', exits if NULL is passed or no memory */
void matDispI(const matriceI *dis);/* Prints matrice 'in' to console, exits if NULL is passed */
int *matP2AI(const matriceI *dis);/* Returns pointer to linear array with matrice 'dis' content, exits if NULL is passed or no memory */
void matKillI(matriceI *vic);/* Frees matrice & contents */
#endif
