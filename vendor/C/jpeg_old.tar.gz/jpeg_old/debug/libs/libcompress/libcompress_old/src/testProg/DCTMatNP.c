#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <memory.h>
#include "../lib/matr.h"
#include "../lib/constants.h"

int main(int argc, char **argv)
{
  matriceD cosMat;
  unsigned short i = 0,j = 0;

  matMakeDNP(&cosMat, VECLEN, VECLEN);

  for(i = 0;i < VECLEN;i++)
    {
      for(j = 0;j < VECLEN;j++)
	{
	  cosMat.ptr[i*VECLEN + j] = cos( ((2.0*j+1.0)*PI*i/2.0/VECLEN) );
	}
    }

  matDispD(&cosMat);

  matKillDNP(&cosMat);

  return 0;
}
