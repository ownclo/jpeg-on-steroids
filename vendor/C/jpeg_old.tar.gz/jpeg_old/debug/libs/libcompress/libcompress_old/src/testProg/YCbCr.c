#include <stdlib.h>
#include <stdio.h>
#include "../lib/bmpjpeg.h"
#include "../lib/constants.h"

int main(int argc, char *argv[])
{
  PDRGB *in = NULL, *out = NULL;
  PDCBCR *middle = NULL;

  in = getRGBFromFile(argv[1]);
  middle = RGBtoCBCR(in);
  out = CBCRtoRGB(middle);
  writeToBMP("O.bmp", out);

  freeCBCR(middle);
  freeRGB(in);
  freeRGB(out);

  return 0;
}
