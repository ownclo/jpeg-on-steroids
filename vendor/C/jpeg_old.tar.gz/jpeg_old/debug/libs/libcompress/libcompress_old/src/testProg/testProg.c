#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <memory.h>
#include <malloc.h>
#include "../lib/compress.h"
#include "../lib/constants.h"

#define ALLOWED "ASVE:D:h"

int main(int argc, char *argv[])
{
  char *name = NULL, *oname = malloc(sizeof(char)*36), i=0, j=0;
  unsigned char isAdaptive = 0, decode = 0, encode = 0;
  (void)memset(oname, 0, sizeof(char) * 36);

  if(argc < 2)
    {
      (void)free(oname);
      (void)puts("Error: I require arguments.");
      exit(-8);
    }

  while( (j = getopt( argc, argv, ALLOWED)) != -1)
    {
      i++;
      switch (j)
	{
	  case 'A':
	    (void)puts("Using adaptive Huffman coding.");
	    isAdaptive = T;
	    break;
	  case 'S':
	    (void)puts("Using non-adaptive Huffman coding.");
	    isAdaptive = F;
	    break;
	  case 'V':
	    toggleVis();
	    break;
	  case 'E':
            encode = T;
            decode = F;
	    name = argv[i];
	    break;
	  case 'D':
	    decode = T;
	    encode = F;
	    name = argv[i];
	    break;
	  case 'h':
            encode = decode = isAdaptive = 128;
	    break;
	}
      }

    if( isAdaptive == F && encode == T && decode == F)
      {
	genFreq(name);
	srtFreq();
	buildTreeBase();
	buildTree();
        (void)memcpy(oname, name, sizeof(char)*32);
	oname = strcat(oname, ".hcf");
        writeToFile( name, oname );
      }
    else if( isAdaptive == F && decode == T && encode == F)
      {
	readFromFile(name);
      }
    else if(isAdaptive == T && encode == T && decode == F)
      {
	(void)memcpy(oname, name, sizeof(char)*32);
	oname = strcat(oname, ".acf");
	initAll();
	adaptCode(name, oname);
      }
    else if(isAdaptive == T && encode == F && decode == T)
      {
	(void)puts("Please type in output filename(MAX 35 characters):");
	oname = fgets(oname,36,stdin);
	initAll();
	adaptDecode(name, oname);
      }
    else if( isAdaptive == 128 && decode == 128 && encode == 128)
      {
	(void)puts("Help for Huffman compressor.\nA...Use adaptive Huffman algorithm.\nH...Use Huffman non-adaptive algorithm.\nE [file]...Encode file [file].\nD [file]...Decode file [file].\nh...Recall help for program.\n");
      }

  (void)free(oname);
  return 0;
}
