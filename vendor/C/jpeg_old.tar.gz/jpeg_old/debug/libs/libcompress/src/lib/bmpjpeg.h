#ifndef _JPEG_
#define _JPEG_

/* BMP header structure */
#pragma pack(2) /*2 byte packing */
typedef struct
{
	unsigned short int type;
	unsigned int size;
	unsigned short int reserved1,reserved2;
	unsigned int offset;
}BMPHEADER;

#pragma pack() /* Default packing */
typedef struct
{
	unsigned int size;
	int width,height;
	unsigned short planes;
	unsigned short int bits;
	unsigned int compression;
	unsigned int imagesize;
	int xresolution,yresolution;
	unsigned int ncolors;
	unsigned int importantcolors;
}BMPINFOHEADER;

/* Structure to store pixel in RGB colorspace */
typedef struct
{
	unsigned char B;
	unsigned char G;
	unsigned char R;
}BMPPIX8BNA;

/* Structure to store RGB pixel data */
typedef struct
{
  unsigned int w, h;
  BMPPIX8BNA *data;
  unsigned char dBytes;
}PDRGB;

/* Structure to store YCBCR pixel data with decimation */
typedef struct
{
  unsigned int w, h;
  unsigned char dBytes;
  short *Ydata;
  short *CbData;
  short *CrData;
}PDCBCR;

/* Structure for storing DCT output blocks, sequenly */
typedef struct
{
  unsigned int YBlks, CBlks, w, h;
  double *YdataDCT;
  double *CbDataDCT;
  double *CrDataDCT;
}DCTDATA;

#ifdef DEBUG
void genrateSpec(const double *in); /* Debug function for building a spectre, does nothing */
void testDCT(unsigned char qRate); /* Test operation of DCT */
void testPSNROnLena(PDCBCR *bfore, PDCBCR *aft, unsigned short blkNum); /* Calculate PSNR & SNR */
#endif

PDRGB *getRGBFromFile(const char *fName); /* Fetches graphic data from file fName, and stores pixel data in memory, returns pointer to data container. */
PDCBCR *RGBtoCBCR(const PDRGB *in); /* Converts pixel data in RGB to YCbCr format, returns pointer to data container. */
PDRGB *CBCRtoRGB(const PDCBCR *in); /* Convert pixel data in YCbCr to RGB format, returns pointer to data container */
void writeToBMP(const char *fName, const PDRGB *dataToWrite); /* Write RGB data to file, used for testing */
double *getDCTedBlock(unsigned char blkType, unsigned int blkNum, const PDCBCR *in); /* Returns quantized, DCT'ed 8x8 block of YCbCr data */
DCTDATA *vomit(const PDCBCR *in, unsigned short qRate); /* This function will return DCT'ed image as subsequent blocks */
PDCBCR *returnFromDCT( DCTDATA *data, unsigned short qrate ); /* This function will bring us back from DCT */


void freeRGB(PDRGB *in);/* Frees PDRGB container */
void freeCBCR(PDCBCR *in);/* Frees PDRGB container */
void freeDCT(DCTDATA *in);/* Frees PDRGB container */
#endif
