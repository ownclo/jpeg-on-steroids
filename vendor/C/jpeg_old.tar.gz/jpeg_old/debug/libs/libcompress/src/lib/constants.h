#ifndef CONSTS_H
#define CONSTS_H

/*====================================*/
/*=========BITSTREAM_SECTION==========*/
/*====================================*/

#define VECLEN 8 /* Dimensions of our matrix and not only matrix, in other words, don't change it! */

/*====================================*/
/*============MATH_SECTION============*/
/*====================================*/

#define PI 3.141592654 /* Relatively accurate PI number definition */
#define T 255 /* True value */
#define F 0 /* False value */
#define UP -1 /* Indicator for going up */
#define DOWN 1 /* Indicator for going down */
#define STEP (VECLEN - 1) /* Step for our zigzag */

/*====================================*/
/*===========ERRORS_SECTION===========*/
/*====================================*/

#define NOMEM "ERROR: No free memory left!"
#define DIFFSIZE "ERROR: Matrices are different of size!"
#define INVSIZE "ERROR: Inconsistent row/column count in matrices!"
#define PRONULL "ERROR: NULL given instead of argument!"
#define INVARG "ERROR: Invalid argument given!"
#define NOBMP "ERROR: This is not a BMP file, son!"
#define NOFOPENREAD "ERROR: Can't open file for reading!"
#define NOFOPENWRITE "ERROR: Can't open file for writing!"

/*====================================*/
/*==========IMAGING_SECTION===========*/
/*====================================*/

#define BMPTYPE 0x4D42 /*BMP magic number*/

#define YR 0.299 /*Coefficent for switching to YCBCR colorspace (Used to calc. Y)*/
#define YG 0.587 /*Coefficent for switching to YCBCR colorspace (Used to calc. Y)*/
#define YB 0.114 /*Coefficent for switching to YCBCR colorspace (Used to calc. Y)*/

#define CB 0.5643 /*Coefficent for switching to YCBCR colorspace (Used to calc CB)*/
#define CR 0.7132 /*Coefficent for switching to YCBCR colorspace (Used to calc CB)*/

#define YCR -0.714 /*Coefficent for restoring green component*/
#define YCB -0.334 /*Coefficent for restoring green component (the second one)*/
#define RCR 1.402 /*Coefficent for restoring red component*/
#define BCR 1.772 /*Coefficent for restoring blue component*/

#define DECRATE 4 /*Decimation rate for CB & CR values*/

#define YTYPE 64 /* Magic number for Y block */
#define CBTYPE 32 /* Magic number for Cb block */
#define CRTYPE 16 /* Magic number for Cr block */

/*====================================*/
/*============JFIF_SECTION============*/
/*====================================*/

#define SOI 
#endif
