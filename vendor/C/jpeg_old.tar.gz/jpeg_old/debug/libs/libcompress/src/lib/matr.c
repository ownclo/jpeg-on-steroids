#include <stdlib.h>
#include <memory.h>
#include <malloc.h>
#include "matr.h"
#include "constants.h"

/* Cosine matrice for DCT */
const double COSMAT[64] = { +.353553, +.353553, +.353553, +.353553, +.353553, +.353553, +.353553, +.353553,
			    +.490392, +.415734, +.277785, +.097545, -.097545, -.277785, -.415734, -.490392,
			    +.461939, +.191341, -.191341, -.461939, -.461939, -.191341, +.191341, +.461939,
			    +.415734, -.097545, -.490392, -.277785, +.277785, +.490492, +.097545, -.415734,
			    +.353553, -.353553, -.353553, +.353553, +.353553, -.353553, -.353553, +.353553,
			    +.277785, -.490392, +.097545, +.415734, -.415734, -.097545, +.490392, -.277785,
			    +.191341, -.461939, +.461939, -.191341, -.191341, +.461939, -.461939, +.191341,
			    +.097545, -.277785, +.415734, -.490392, +.490392, -.415734, +.277785, -.097545};

/* TEST CODE */
#ifdef DEBUG
void matMakeDNP(matriceD *ptr, unsigned short x, unsigned short y)
{
  if( !ptr )
    {
      (void)puts(PRONULL);
      return;
    }

  if( !x || !y )
    {
      (void)puts(INVSIZE);
      return;
    }

  ptr->ptr = malloc(sizeof(double)*x*y);

  if( !ptr->ptr )
    {
      (void)puts(NOMEM);
      return;
    }

  (void)memset(ptr->ptr,0,sizeof(double)*x*y);
  ptr->x = x;
  ptr->y = y;
}

void matKillDNP(matriceD *ptr)
{
  if( !ptr && !ptr->ptr)
    {
      (void)free(ptr->ptr);
    }
}
#endif
/* END TC */

matriceD *matMakeD(unsigned short x,unsigned short y)
{
  matriceD *out = NULL;
  unsigned int size = x*y;

  if( !size )
    {
      (void)puts(INVSIZE);
      return NULL;
    }

  out = malloc(sizeof(matriceD));

  if( !out )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out,0,sizeof(matriceD));
  out->ptr = malloc(sizeof(double)*size);
  out->x = x;
  out->y = y;

  if( !(out->ptr) )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out->ptr,0,sizeof(double)*size);

  return out;
}

matriceD *matTranspondD(const matriceD *in)
{
  matriceD *out = NULL;
  unsigned short i = 0,j = 0, x, y;

  if( !in )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  x = in->x;
  y = in->y;

  out = malloc(sizeof(matriceD));
  (void)memset(out,0,sizeof(matriceD));

  if( !out )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  out->ptr = malloc(sizeof(double)*x*y);

  if( !(out->ptr) )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out->ptr,0,sizeof(double)*x*y);

  for(i = 0; i < y; i++)
    {
      for(j = 0; j < x; j++)
        {
          *(out->ptr + (i*x) + (j) ) = *(in->ptr + (j*x) + (i) );
        }
    }

  out->x = in->y;
  out->y = in->x;

  return out;
}

matriceD *matAddD(const matriceD *M1,const matriceD *M2)
{
  matriceD *out = NULL;
  unsigned short i = 0,j = 0;

  if(M1 == NULL || M2 == NULL)
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if(M1->x != M2->x || M1->y != M2->y)
    {
      (void)puts(DIFFSIZE);
      return NULL;
    }

  out = malloc(sizeof(matriceD));

  if(out == NULL)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  out->ptr = malloc(sizeof(double)*M1->x*M1->y);

  if(out->ptr == NULL)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  for(i = 0;i < M1->y;i++)
    {
      for(j = 0;j < M2->x; j++)
        {
          *(out->ptr + i*VECLEN + j) = *(M1->ptr + i*VECLEN + j) + *(M2->ptr +  i*VECLEN + j);
        }
    }

  out->y = M1->y;
  out->x = M1->x;

  return out;
}

matriceD *matMultD(const matriceD *M1,const matriceD *M2)
{
  matriceD *out = NULL;
  unsigned short i = 0, j = 0, k = 0, tmp = 0;

  if(M1 == NULL || M2 == NULL)
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if(M1->x != M2->y)
    {
      (void)puts(INVSIZE);
      return NULL;
    }

  out = malloc(sizeof(matriceD));

  if(out == NULL)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  out->ptr = malloc(sizeof(double)*M2->x*M1->y);

  if(out->ptr == NULL)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  tmp = M2->x;

  for(i = 0; i < M1->y; i++)
    {
      for(j = 0; j < tmp; j++)
	{
	  for(k = 0; k < tmp; k++)
	    {
	      *(out->ptr + (i*VECLEN) + (j)) += *(M1->ptr + (i*VECLEN) + (k)) * *(M2->ptr + (k*VECLEN) + (j));
	    }
	}
    }

  out->y = M1->y;
  out->x = tmp;

  return out;
}

matriceD *matGenNormD(void)
{
  matriceD *out = NULL;

  out = malloc(sizeof(matriceD));

  if( !out )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out,0,sizeof(matriceD));

  out->ptr = malloc(sizeof(double)<<6);

  if( !out->ptr )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out->ptr,0,sizeof(double)<<6);

  *(out->ptr) = 0.353553;
  *(out->ptr + 1 + VECLEN) = 0.5;
  *(out->ptr + 2 + (VECLEN<<1)) = 0.5;
  *(out->ptr + 3 + (VECLEN<<1) + VECLEN) = 0.5;
  *(out->ptr + 4 + (VECLEN<<2)) = 0.5;
  *(out->ptr + 5 + (VECLEN<<2) + VECLEN) = 0.5;
  *(out->ptr + 6 + ((VECLEN + VECLEN + VECLEN)<<1) ) = 0.5;
  *(out->ptr + 7 + ((VECLEN<<3) - VECLEN)) = 0.5;

  out->x = VECLEN;
  out->y = VECLEN;

  return out;
}

void matDispD(const matriceD *dis)
{
  unsigned short i = 0;

  if(dis != NULL)
    {
      for(i=0;i<dis->y*dis->x;i++)
	{
	  switch (i&7)
	   {
	     case 0:
	      (void)printf(" %2.2f", *(dis->ptr + i) );
	      break;
	     case 7:
	      (void)printf(" %2.2f \n", *(dis->ptr + i) );
	      break;
	     default:
	      (void)printf(" %2.2f", *(dis->ptr + i) );
	      break;
	   }
	}
      putchar('\n');
    }
  else
    {
      (void)puts(PRONULL);
      return;
    }
}

double *matP2AD(const matriceD *in)
{
  unsigned short i = 0, j = 0;
  double *out = NULL;

  if( !in )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if( !in->ptr )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  i = in->x;
  j = in->y;
  out = malloc(sizeof(double)*i*j);
  (void)memset(out,0,sizeof(double));

  for(i = 0;i < in->y;i++)
    {
      for(j = 0; j < in->x;j++)
	{
	  *(out + i*in->x + j) = *(in->ptr + i*in->x + j);
	}
    }

  return out;
}

void matKillD(matriceD *vic)
{
  if(vic != NULL)
    {
      if(vic->ptr != NULL)
	{
	  (void)memset(vic->ptr, 0, sizeof(double)*vic->x*vic->y);
	  (void)free(vic->ptr);
	}
      (void)memset(vic, 0, sizeof(matriceD));
      (void)free(vic);
    }
  else
    {
      (void)puts(PRONULL);
      return;
    }
}

matriceD *prepDCT(void)
{
  matriceD *out = malloc(sizeof(double)<<6);

  out->ptr = malloc(sizeof(double)<<6);
  (void)memcpy(out->ptr,&COSMAT,sizeof(double)<<6);

  out->x = VECLEN;
  out->y = VECLEN;

  return out;
}

double getValAt(unsigned char x, unsigned char y, const matriceD *source)
{

  if(source != NULL && x < 8 && y < 8)
    {
      return *(source->ptr + x + (y<<3) );
    }

  return -3.14;
}

matriceI *matMakeI(unsigned short x,unsigned short y)
{
  matriceI *out = NULL;
  unsigned int size = x*y;

  if( !size )
    {
      (void)puts(INVSIZE);
      return NULL;
    }

  out = malloc(sizeof(matriceI));

  if( !out )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out,0,sizeof(matriceI));
  out->ptr = malloc(sizeof(int)*size);
  out->x = x;
  out->y = y;

  if( !(out->ptr) )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out->ptr,0,sizeof(int)*size);

  return out;
}

matriceI *matTranspondI(const matriceI *in)
{
  matriceI *out = NULL;
  unsigned short i = 0,j = 0, x, y;

  if( !in )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  x = in->x;
  y = in->y;

  out = malloc(sizeof(matriceI));

  if( !out )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out,0,sizeof(matriceI));
  out->ptr = malloc(sizeof(int)*x*y);

  if( !(out->ptr) )
    {
      (void)puts(NOMEM);
      return NULL;
    }

  (void)memset(out->ptr,0,sizeof(int)*x*y);

  for(i = 0; i < y; i++)
    {
      for(j = 0; j < x; j++)
        {
          *(out->ptr + (i*x) + (j) ) = *(in->ptr + (j*x) + (i) );
        }
    }

  out->x = in->y;
  out->y = in->x;

  return out;
}

matriceI *matAddI(const matriceI *M1,const matriceI *M2)
{
  matriceI *out = NULL;
  unsigned short i = 0,j = 0;

  if(M1 == NULL || M2 == NULL)
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if(M1->x != M2->x || M1->y != M2->y)
    {
      (void)puts(DIFFSIZE);
      return NULL;
    }

  out = malloc(sizeof(matriceI));

  if(out == NULL)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  out->ptr = malloc(sizeof(int)*M1->x*M1->y);

  if(out->ptr == NULL)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  for(i = 0;i < M1->y;i++)
    {
      for(j = 0;j < M2->x; j++)
        {
          *(out->ptr + i*VECLEN + j) = *(M1->ptr + i*VECLEN + j) + *(M2->ptr +  i*VECLEN + j);
        }
    }

  out->y = M1->y;
  out->x = M1->x;

  return out;
}

matriceI *matMultI(const matriceI *M1,const matriceI *M2)
{
  matriceI *out = NULL;
  unsigned short i = 0, j = 0, k = 0, tmp = 0;

  if(M1 == NULL || M2 == NULL)
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if(M1->x != M2->y)
    {
      (void)puts(INVSIZE);
      return NULL;
    }

  out = malloc(sizeof(matriceI));

  if(out == NULL)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  out->ptr = malloc(sizeof(int)*M2->x*M1->y);

  if(out->ptr == NULL)
    {
      (void)puts(NOMEM);
      return NULL;
    }

  tmp = M2->x;

  for(i = 0; i < M1->y; i++)
    {
      for(j = 0; j < tmp; j++)
	{
	  for(k = 0; k < tmp; k++)
	    {
	      *(out->ptr + (i*VECLEN) + (j)) += *(M1->ptr + (i*VECLEN) + (k)) * *(M2->ptr + (k*VECLEN) + (j));
	    }
	}
    }

  out->y = M1->y;
  out->x = tmp;

  return out;
}

void matDispI(const matriceI *dis)
{
  unsigned short i = 0;

  if(dis != NULL)
    {
      for(i=0;i<dis->y*dis->x;i++)
	{
	  switch (i&7)
	   {
	     case 0:
	      (void)printf("| %d", *(dis->ptr + i) );
	      break;
	     case 7:
	      (void)printf(" %d |\n", *(dis->ptr + i) );
	      break;
	     default:
	      (void)printf(" %d", *(dis->ptr + i) );
	      break;
	   }
	}
        putchar('\n');
    }
  else
    {
      (void)puts(PRONULL);
      return;
    }
}

int *matP2AI(const matriceI *in)
{
  unsigned short i = 0, j = 0;
  int *out = NULL;

  if( !in )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  if( !in->ptr )
    {
      (void)puts(PRONULL);
      return NULL;
    }

  i = in->x;
  j = in->y;
  out = malloc(sizeof(int)*i*j);
  (void)memset(out,0,sizeof(int)*i*j);

  for(i = 0;i < in->y;i++)
    {
      for(j = 0; j < in->x;j++)
	{
	  *(out + i*in->x + j) = *(in->ptr + i*in->x + j);
	}
    }

  return out;
}

void matKillI(matriceI *vic)
{
  if(vic != NULL)
    {
      if(vic->ptr != NULL)
	{
	  (void)memset(vic->ptr, 0, sizeof(int)*vic->x*vic->y);
	  (void)free(vic->ptr);
	}
      (void)memset(vic, 0, sizeof(matriceI));
      (void)free(vic);
    }
  else
    {
      (void)puts(PRONULL);
      return;
    }
}
