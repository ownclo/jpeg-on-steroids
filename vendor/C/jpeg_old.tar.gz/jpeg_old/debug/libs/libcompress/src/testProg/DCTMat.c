#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include "../lib/matr.h"
#include "../lib/constants.h"

#define PI 3.141592654

int main(int argc, char **argv)
{
  matriceD *cosMat = NULL, *cosMatT = NULL, *cosMatM = NULL, *nMat = NULL, *nMatM = NULL, *testMat = NULL;

  cosMat = prepDCT();

  matDispD(cosMat);

  testMat = matMakeD(VECLEN, 1);
  *(testMat->ptr) = 33;
  *(testMat->ptr+1) = 32;
  *(testMat->ptr+2) = 31;
  *(testMat->ptr+3) = 32;
  *(testMat->ptr+4) = 33;
  *(testMat->ptr+5) = 32;
  *(testMat->ptr+6) = 31;
  *(testMat->ptr+7) = 32;




  cosMatT = matTranspondD(cosMat);

  cosMatM = matMultD(testMat, cosMatT);

  (void)puts("Transponding matrice.");
  matDispD(cosMatT);
  (void)puts("Multiplication of test matrice.");
  matDispD(cosMatM);
  matKillD(testMat);

  testMat = matMultD(cosMatM, cosMat);

  (void)puts("Recovery of matrice.");
  matDispD(testMat);
  matKillD(cosMatM);

  cosMatM = matMultD(cosMat, cosMatT);

  (void)puts("Testing matrice multiplication (DCT matrices).");
  matDispD(cosMatM);

  nMat = matGenNormD();

  matDispD(nMat);

  nMatM = matMultD(cosMatM, nMat);

  matDispD(nMatM);

  matKillD(testMat);
  matKillD(cosMat);
  matKillD(cosMatM);
  matKillD(cosMatT);
  matKillD(nMat);
  matKillD(nMatM);

  return 0;
}
