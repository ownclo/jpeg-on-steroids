#include <stdlib.h>
#include <stdio.h>
#include "../lib/bmpjpeg.h"
#include "../lib/constants.h"

int main(int argc, char *argv[])
{
  PDRGB *in = NULL;
  PDCBCR *middle = NULL;
  DCTDATA *out = NULL;
  short *sh = NULL, i = 0;

  in = getRGBFromFile(argv[1]);
  middle = RGBtoCBCR(in);

  out = vomit(middle, 8);

  (void)puts("Testing the acquisition of Y block #42:");
  sh = getDCTedBlock(YTYPE, 42, middle);

  for(i = 0;i < 1<<6;i++)
    {
      (i % 8 == 0) ? ( putchar('\n') ) : (0);
      (void)printf("%d ",*(sh + i));
    }

  (void)putchar('\n');

  (void)free(sh);

  (void)puts("Testing the acquisition of Cb block #42:");
  sh = getDCTedBlock(CBTYPE, 42, middle);

  for(i = 0;i < 1<<6;i++)
    {
      (i % 8 == 0) ? ( putchar('\n') ) : (0);
      (void)printf("%d ",*(sh + i));
    }

  (void)putchar('\n');

  (void)free(sh);

  (void)puts("Testing the acquisition of Cr block #42:");
  sh = getDCTedBlock(CRTYPE, 42, middle);

  for(i = 0;i < 1<<6;i++)
    {
      (i % 8 == 0) ? ( putchar('\n') ) : (0);
      (void)printf("%d ",*(sh + i));
    }

  (void)putchar('\n');

  (void)fflush(stdout);

  freeDCT(out);
  freeCBCR(middle);
  freeRGB(in);
  (void)free(sh);

  return 0;
}
