#ifdef DEBUG
#include <math.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include "../lib/bmpjpeg.h"
#include "../lib/constants.h"

int main(int argc, char *argv[])
{
  PDRGB *in = NULL;
  PDCBCR *middle = NULL, *aft = NULL;
  DCTDATA *out = NULL;

#ifdef DEBUG
  testDCT(4);
#endif

  in = getRGBFromFile(argv[1]);
  middle = RGBtoCBCR(in);
  out = vomit(middle, (!argv[2]) ? ( 0 ) : ( atoi(argv[2]) ));

  freeRGB(in);

  aft = returnFromDCT(out, (!argv[2]) ? ( 0 ) : ( atoi(argv[2]) ));
  freeDCT(out);
  in = CBCRtoRGB(aft);
  writeToBMP("O.bmp", in);

#ifdef DEBUG
  testPSNROnLena(middle, aft, 1);
#endif

  freeCBCR(middle);
  freeCBCR(aft);
  freeRGB(in);

  return 0;
}
