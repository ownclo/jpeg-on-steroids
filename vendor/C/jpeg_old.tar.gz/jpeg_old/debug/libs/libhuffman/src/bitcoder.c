#include "huffman.h"	
#include <stdio.h>
#include <stdlib.h>

/* supposing that we have a function 'encode_ac', that encodes an ac symbol, and a function 'putbits' that provides bit output */

/* let us suppose that we have a counts' function. All that we need then, consists in the function that I've already made 'encode/decode' in the HUFFMAN package. So I'll just wait for PTA for that */

int incri (int* i, NODEP nodes, int len)
{
	*i = *i + 1;
	while ((*i < 2*len - 1) && ((nodes[*i].parent != NULL) || (nodes[*i].weight == -1) || (nodes[*i].weight == 0)))		// like'a Lisp!
		*i = *i + 1;

	return EXIT_SUCCESS;
}

int add (int* freeplace, unsigned int depth, unsigned int path, unsigned int* lol, int* cur)
{
	int t;
	t = *freeplace - ((int) depth);
	unsigned int pt = path;
	if (t >= 0)
	{
		lol[*cur] = lol[*cur] | (path << t);
		*freeplace -= depth;
		if (*freeplace == 0)
		{
			*cur = *cur + 1;
			*freeplace = 32;
//			printf ("%X\n", lol[*cur - 1]);
		}
	}
	else
	{
		lol[*cur] = lol[*cur] | (pt >> (-1*t));
		t = 32 + t;
		*cur = *cur + 1;
		*freeplace = 32;
//		printf ("%X\n", lol[*cur - 1]);
		add (freeplace, (-1 * (t - 32)), (((1 << (-1 * (t- 32))) - 1) & path), lol, cur);		// deep brainfuck math? Noway.
	}


	return 1;
}

int twomins (int* first, int* second, NODEP nodes, int len)
{
	int i = 0;
	if ((nodes[i].weight) == -1 || (nodes[i].parent) != NULL || (nodes[i].weight == 0))
		incri(&i, nodes, len);

	int firstmin = i;
	incri(&i, nodes, len);
	int secondmin = i;
	if (nodes[secondmin].weight < nodes[firstmin].weight)
	{
		int t = firstmin;
		firstmin = secondmin;
		secondmin = t;
	}
	incri(&i, nodes, len);
	for (; i < (2*len -1); incri(&i, nodes, len))
	{
		if (nodes[i].weight < nodes[firstmin].weight)
		{
			secondmin = firstmin;
			firstmin = i;
		}
		else
			if (nodes[i].weight < nodes[secondmin].weight)
			{
				secondmin = i;
			}
	}
	*first = firstmin;
	*second = secondmin;
	return 1;
}

int uiui (int firstmin, int secondmin, int cow, NODEP nodes)
{
	if (! ((firstmin == -1) && (secondmin == -1)))
			{
		nodes[cow].leftchild = &nodes[firstmin];
		nodes[cow].rightchild = &nodes[secondmin];
		nodes[cow].weight = nodes[firstmin].weight + nodes[secondmin].weight;
		nodes[firstmin].parent = &nodes[cow];
		nodes[secondmin].parent = &nodes[cow];
			}

	return 1;
}

NODEP findroot (int* i, NODEP nodes)
		{
	NODEP res = NULL;
	if (nodes[*i].parent != NULL)
	{
		res = &nodes[*i];
		while (res->parent != NULL)
		{
		res = res->parent;
		}
	}
	return res;
}

int form_tree (FILE* stream, int* counts, int num_of_elms, REZP cd)
{
	int firstmin = 0;
	int secondmin = 0;
	int i = 0;
	int cow = num_of_elms; 
	NODEP nodes;
	int sizeoftree = num_of_elms*2-1;
	int powerofalph = 0;
	unsigned char *alph;
	int freeplace = 32; int cur = 0;
	unsigned int* treecode;
	nodes = (NODEP) calloc (sizeoftree, sizeof (NODE));
	alph = (unsigned char*) calloc (num_of_elms, sizeof(unsigned char));
	treecode = (unsigned int *) calloc ( 16, sizeof (int));

	for (i = 0; i < num_of_elms; i++)
	{
		nodes[i].letter = (unsigned char) i;
		nodes[i].weight = counts[i];
		nodes[i].leftchild = NULL;
		nodes[i].rightchild = NULL;
		nodes[i].parent = NULL;
	}
	for (int i = num_of_elms; i < sizeoftree; i++)
	{
		nodes[i].weight = -1;
		nodes[i].letter = 0;
		nodes[i].leftchild =  NULL;
		nodes[i].rightchild = NULL;
		nodes[i].parent = NULL;
	}

	for (; ((firstmin < sizeoftree) && (secondmin < sizeoftree)) ; cow++)
		{
		twomins (&firstmin, &secondmin, nodes, num_of_elms);
		if((firstmin < sizeoftree) && (secondmin < sizeoftree))
		{
			uiui(firstmin, secondmin, cow, nodes);
			firstmin = -1;
			secondmin = -1;
		}
	}
	int l = num_of_elms;
	for (int k = 0; k < num_of_elms; k++)
	{
		cd[k].depth = 0;
		cd[k].path = 0;
		cd[k].weight = 0;
	}

	dfs (findroot(&l, nodes), 0, 0, cd, &powerofalph, alph, treecode, &freeplace, &cur);
	fwrite ( &powerofalph, sizeof ( int ), 1, stream );
	fwrite ( alph, sizeof ( char ), powerofalph, stream);
	int sizeoftreecode = (2*powerofalph - 1)/32  + 1;
	fwrite ( treecode, sizeof (unsigned int), sizeoftreecode, stream);
	
	free(nodes);
	free(alph);
	free(treecode);
	return EXIT_SUCCESS;
}

int
dfs(NODEP root, int num, int dep, REZP cd, int* nimno, unsigned char* alph, unsigned int* treecode, int* freeplace, int* cur)
{
//	int freeplace = 32;
//	int cur = 0;

	if (root->leftchild != NULL)
    {
		add (freeplace, 1, 1, treecode, cur);
		dfs(root->leftchild, (num << 1), (dep + 1), cd, nimno, alph, treecode, freeplace, cur);
		dfs(root->rightchild, ((num << 1)|1), (dep + 1), cd, nimno, alph, treecode, freeplace, cur);
    }
	else
    {
		add (freeplace, 1, 0, treecode, cur );
		alph [*nimno ] = root->letter;
		*nimno = *nimno + 1;
		cd[root->letter].path = num;
		cd[root->letter].depth = dep;
		cd[root->letter].weight = root->weight;
//		printf("%c--%d--%d\n",root->letter, root->weight, cd[root->letter].depth);
      return 1;
    }

  return 1;
}

NODE uniui(NODEP first, NODEP second)
{
  NODE newp;
  newp.leftchild = first;
  newp.rightchild = second;
  return newp;
}

int encode (FILE* src, REZP cd, FILE* outp)
{
	int frp = 32;
	int len = 0;
	int i = 0;
	for (i = 0; i < 256; i++)
	{
		len += cd[i].weight * cd[i].depth;
	}
	int ll = len/32 + (len%32 != 0) * 1;


	int a = ftell(src);
	fseek(src, 0L, SEEK_END);
	int b = ftell(src);
	int* length;
	length = (int*) malloc (sizeof(int)*1);
	length[0] = b - a;
	fseek(src, 0L, SEEK_SET);
    unsigned char* file;
    file = (unsigned char*) malloc (sizeof(unsigned char) * length[0]);
    (void) fread(file, sizeof(char), length[0], src);
    fseek(src, 0L, SEEK_SET);

//  cd[(int) file[i]].path;
    int cur = 0;
    unsigned int *lb = (unsigned int*) calloc (ll, sizeof (unsigned int));
    
    for(i = 0; i < length[0]; i++)
    {
    	add (&frp, cd[(int) file[i]].depth, cd[(int) file[i]].path, lb, &cur);
    }

    fwrite (lb, sizeof(unsigned int), ll, outp);
    free (file);
    fclose (outp);


	return 1;
}
