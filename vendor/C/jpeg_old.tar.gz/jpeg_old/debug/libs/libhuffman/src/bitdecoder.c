#include "huffman.h"
#include <stdio.h>
#include <stdlib.h>
unsigned int getbitstream (unsigned int* stream, int* cellnum, int* bitnum, int length)
{
	unsigned int rez;

	if ( *bitnum >= length )
	{
		rez = (stream[*cellnum] >> (*bitnum - length)) & ((1 << length) - 1);
		*bitnum = *bitnum - length;
		if (*bitnum == 0)
		{
			*cellnum = *cellnum + 1;
			*bitnum = 32;
		}
	}
	else
	{
		rez = ((stream[*cellnum] & ((1 << *bitnum) - 1)) << (length - *bitnum)) | (stream[*cellnum + 1] >> (32 - length + *bitnum));
		*cellnum = *cellnum + 1;
		*bitnum = 32 - length + *bitnum;
	}
	return rez;
}

int refill (char wd, unsigned int path, unsigned int depth, DECOP recd )
{ /* Generate the decode table */
	int i;
	for (i = 0; i <= ((1 << (22 - depth)) - 1); i ++)
	{
		recd [ (path << (22 - depth)) + i ].letter = wd;
		recd [ (path << (22 - depth)) + i ].length = depth;
	}
	return 1;
}

NODEP dfr ( char* string, int* cur, unsigned char* alphabet, int* curalphabet, NODEP parent)
{ /* Restore the tree from it's code */
	NODEP newnode;
	newnode = (NODEP) malloc (sizeof(NODE));
	if ( string [*cur] == '1' )
	{
		*cur = *cur + 1;
		newnode->leftchild = dfr (string, cur, alphabet, curalphabet, newnode);
		newnode->rightchild = dfr(string, cur, alphabet, curalphabet, newnode);
		newnode->letter = 0;
		newnode->parent = parent;
		newnode->weight = -1;
		return newnode;
	}
	if ( string [*cur] == '0' )
	{
		*cur = *cur + 1;
		newnode->leftchild = NULL;
		newnode->rightchild = NULL;
		newnode->letter = alphabet[*curalphabet];
		*curalphabet = *curalphabet + 1;
		newnode->weight = 0;
		newnode->parent = parent;
		return newnode;
	}
	return NULL;
}

int dfs_final(NODEP root, int num, int dep, REZP cd)
{ /* Cd's from Node */
	if (root->leftchild != NULL)
    {
		dfs_final(root->leftchild, (num << 1), (dep + 1), cd);
		dfs_final(root->rightchild, ((num << 1) + 1), (dep + 1), cd);
    }
	else
    {
		cd[root->letter].path = num;
		cd[root->letter].depth = dep;
		cd[root->letter].weight = root->weight;
      	return 1;
    }
    return 1;
}
int free_tree (NODE* treeptr)
{
	if (treeptr->leftchild != NULL)
	{
		free_tree (treeptr->leftchild);
		free_tree (treeptr->rightchild);
	}
		
	free (treeptr);
	return EXIT_SUCCESS;
}

unsigned char decosymbol (DECOP table, unsigned int* code, unsigned int* buffer, DECOP cur,
				int* current, int* s)
{
	*cur = table[(*buffer >> 10)];
	*buffer = (*buffer << cur->length) | getbitstream (code, current, s, cur->length);
	return cur->letter;
}









