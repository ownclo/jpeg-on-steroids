#include <stdio.h>
#include <stdlib.h>
#include "../src/huffman.h"

int main (void)
{
	int counts[4] = {1, 5, 0, 6};
	int num = 4;
	int i;
	REZ cd[4];
	form_tree (counts, num, cd);
	
	for (i = 0; i < 4; i++)
		printf ("%d\t%d\n", cd[i].path, cd[i].depth);
	
	return EXIT_SUCCESS;
}
