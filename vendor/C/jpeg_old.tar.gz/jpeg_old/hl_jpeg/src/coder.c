#include <stdio.h>
#include <stdlib.h>
#include "hljpeg.h"
#include <string.h>

int main (int argc, char* argv[])
{
    FILE* coded;
    char* fname;
    fname = (char*) calloc (50, sizeof(char));
    fname = strcpy (fname, argv[1]);
    fname = strcat (fname, ".jp");
    coded = fopen(fname, "wb");

    PDRGB *in = NULL;
    PDCBCR *middle = NULL;
    DCTDATA *data = NULL;

    in = getRGBFromFile(argv[1]);
    middle = RGBtoCBCR(in);
    data = toDCT2(middle, (!argv[2]) ? ( 0 ) : ( atoi(argv[2]) ));

    unsigned int* output1;
    unsigned int* output2;
    unsigned int* output3;
    int size1 = 0, size2 = 0, size3 = 0;

    output1 = (unsigned int*) calloc (data->YBlks * 128, sizeof(short int));
    output2 = (unsigned int*) calloc (data->CBlks * 128, sizeof(short int));
    output3 = (unsigned int*) calloc (data->CBlks * 128, sizeof(short int));

    fwrite (&data->w, sizeof(int), 1, coded);
    fwrite (&data->h, sizeof(int), 1, coded);
    fwrite (&data->YBlks, sizeof(int), 1, coded);
    fwrite (&data->CBlks, sizeof(int), 1, coded);

    size1 = coder (coded, data->YdataDCT,  output1, data->YBlks);
    fwrite (&size1, sizeof(int), 1, coded);
    fwrite (output1, sizeof(unsigned int), size1, coded);

    size2 = coder (coded, data->CbDataDCT, output2, data->CBlks);
    fwrite (&size2, sizeof(int), 1, coded);
    fwrite (output2, sizeof(unsigned int), size2, coded);

    size3 = coder (coded, data->CrDataDCT, output3, data->CBlks);
    fwrite (&size3, sizeof(int), 1, coded);
    fwrite (output3, sizeof(unsigned int), size3, coded);

    free(output1);
    free(output2);
    free(output3);

    freeDCT(data);
    freeCBCR(middle);
    freeRGB(in);
    fclose(coded);
    return EXIT_SUCCESS;
}


int coder (FILE* stream, short int* data, unsigned int* output, int n)
{
    int* dc_counts;
    int* ac_counts;
    int i = 0;
    int numofdcs = 16;
    int numofacs = 16*16;
    int freeplace = 32;
    int current_cell = 0;
    short dcprev = 0;
    short delta = 0;
    char bcdc;
    short mgdc;

    REZP cd_dc = (REZP) calloc (numofdcs, sizeof(REZ));
    REZP cd_ac = (REZP) calloc (numofacs, sizeof(REZ));

    dc_counts = (int*) calloc (numofdcs, sizeof(int));
    ac_counts = (int*) calloc (numofacs, sizeof(int));

    counters_dc (data, dc_counts, n);
    counters_ac (data, ac_counts, n);
    form_tree (stream, dc_counts, numofdcs, cd_dc);
    form_tree (stream, ac_counts, numofacs, cd_ac);

    for (i = 0; i < n; i++)
    {
        delta = data[i*64] - dcprev;
        bcmg (delta, &bcdc, &mgdc);
        putbits (cd_dc[bcdc].path, cd_dc[bcdc].depth, output, &current_cell, &freeplace);

        if (bcdc != 0)
        {
            *dcprev = data[i*64];
            putbits ((unsigned int) mgdc, (unsigned int) bcdc, output, &current_cell, &freeplace);
        }
        rle (&data[i*64], cd_ac, output, &current_cell, &freeplace);
    }

    free (cd_dc);
    free (cd_ac);
    free (dc_counts);
    free (ac_counts);

    return current_cell + 2;
}
