#define SIZE 8
#include "../include/bitstream.h"
#include "../include/huffman.h"
#include "../include/bmpjpeg.h"
#include "../include/constants.h"


/*--------BCMG------------*/
char bc (short num);														// Computing bit category of num
int bcmg (short number, char* bcn, short* mg);

/*--------RLE-------------*/
int rle (short* block, REZP cd_ac, 											// RLE of the ZZ block
		 unsigned int* output, int* current_cell, int* freeplace);			// output data
		 
int generate (unsigned char run, short level, REZP cd_ac, 					// Encode a (Run, LvL) pair.
			  unsigned int* output, int* current_cell, int* freeplace);

/*------COUNTERS----------*/												// Encoding of a block

int counters_dc (short int* data, int* dc_counts, int n);
int counters_ac (short int* data, int* ac_counts, int n);
int rle_counters (short* block, int* ac_counts);
int generate_counters (unsigned char run, short level, int* ac_counts);

/*-------HIGH LEVEL--------*/
int coder (FILE* stream, short int* data, unsigned int* output, int n);		// Entrophy coding of an image. HL function interface.
int decode_component (FILE* stream, short* dataDCT, int Blks);				// Entrophy decoding of an image.   


