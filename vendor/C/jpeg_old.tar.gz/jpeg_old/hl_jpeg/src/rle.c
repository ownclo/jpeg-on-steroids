#include <stdio.h>
#include <stdlib.h>
#include "./hljpeg.h"

int rle (short* block, REZP cd_ac, unsigned int* output, int* current_cell, int* freeplace)
{
    unsigned char run = 0;
    int cur;
    int i;
    int no_zeros = 0;
    for (i = 1; i < 64; i++)
    {
        if (block[i] != 0) no_zeros++;
    }
    i = 0;

    for (cur = 1; i < no_zeros; cur++)
    {
        if (block[cur] != 0 || run == 15){
            generate (run, block[cur], cd_ac, output, current_cell, freeplace);
            if (block[cur] != 0) i++;
            run = 0;
        }
        else run++;
    }
    if (cur < 64)	generate (0, 0, cd_ac, output, current_cell, freeplace);
    return EXIT_SUCCESS;
}

int generate (unsigned char run, short level, REZP cd_ac, unsigned int* output, int* current_cell, int* freeplace)
{
    char bc;
    short mg;
    bcmg (level, &bc, &mg);
    putbits (cd_ac[bc*16 + run].path, cd_ac[bc*16+run].depth, output, current_cell, freeplace);
    putbits ((unsigned int) mg, (unsigned int) bc, output, current_cell, freeplace);

    return EXIT_SUCCESS;
}
